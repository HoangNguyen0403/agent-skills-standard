# Catalog Test Remediation — TESTS_READY

Status: `TESTS_READY`; source edits remain frozen until parent observes the required RED and releases implementation.

## Owned changes

- `scripts/generation/isolated-stage.test.ts:243-246`: digest mutation updates the catalog entry and every native binding's `canonicalDigest` together; canonical source bytes remain unchanged. This keeps fixture metadata valid so it reaches the staged canonical-byte mismatch check.
- `scripts/generation/isolated-stage.test.ts:3737-3781`: removed the error-text regex parameter/assertions. Check and apply still assert `success === false`, preserve lock bytes and declared outputs, and cover missing-stage-entry and digest-drift refusals.
- `scripts/generation/isolated-stage.test.ts:3783-3823`: added no-config and zero-agent-with-selected-workflow cases. Both assert successful generation with no published workflow catalog when the local catalog producer is ineligible.

## Invariants and behavioral oracle

Digest drift isolates selected-entry canonical-byte mismatch: each native binding continues to reference the injected entry digest while the actual canonical bytes remain unchanged. This follows `local-provenance-decision.json`; existing binding-mismatch coverage remains separate.

Producer eligibility tests preserve prior no-producer behavior. A repository with canonical workflow files but no configuration, and a configuration selecting `demo` with `agents: []`, do not acquire a required stage catalog. Existing tests continue to require refusal for missing/mismatching staged entries in the enabled producer path. Assertions use observable generation results and resulting lock state, not internal source text or error wording.

## Focused test patterns

Corrected seven-case coverage:
`catalog-only lock change|selected workflow missing|staged catalog digest drifted|consumer lock without a workflow catalog|bootstrapped catalog|unchanged remote catalog entry|new local canonical bytes`

New producer-eligibility cases:
`generation without config|generation with zero agents and selected workflows`

## Verification and limits

No commands or tests were run, per the assigned boundary. `correction-green.log` is prior evidence only: 6 of 7 targeted cases passed; digest drift failed because fixture binding digests were stale. Historical original RED was not rerun because production source was already fixed before this correction. The newly added two cases are frozen for the parent-run RED check. No production source changes have been made in this pass.
