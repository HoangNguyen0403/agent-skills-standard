# FINAL_FROZEN — Producer Eligibility Gate Repair

Status: `FINAL_FROZEN`. Owner `3d061e41-ec72-4b50-8fa3-3ec30a655908`. Parent released source after `bg6` settled corrected-fixture-green 7/7. No commands, tests, build, lint, format, generation, or JSON/shell validation were run in this pass, per the assigned boundary.

## Owned changes (exactly three paths)

### 1. `scripts/generation/isolated-stage.ts` — required inventory gated on loaded config

```ts
  // Explicit overrides keep user-authored canonical bodies out of generation
  // ownership, so they are not required catalog membership either. Without a
  // loaded configuration the catalog producer does not run at all, so no staged
  // catalog entry can be required even when canonical workflow files exist.
  const workflowSources = config
    ? workflowNames
        .map((name) => path.posix.join(".agents", "workflows", `${name}.md`))
        .filter((relPath) => !isOverriddenRel(relPath, overrides))
        .sort()
    : [];
```

Root cause: the inventory was built from local `workflowNames` (lines 630-633 pre-change) regardless of configuration, so a repository with canonical `.agents/workflows/*.md` but no `.skillsrc` produced a non-empty `workflowSources`. `assertRequiredWorkflowCatalog` then unconditionally demanded a staged catalog entry, while `generate-indices` only runs its catalog-producing ownership pass under `config && agents.length > 0`. Result: no-config generation failed closed on an impossible requirement.

Minimality: `workflowSources` is read only by `assertRequiredWorkflowCatalog` (lines 3506/3513) and the plan return; `workflowOutputs`, declaration, retirement, provenance, and catalog merge logic do not consume it. No other source site changed.

Deliberate non-changes:

- Did **not** gate on raw `config.agents.length` or `plan.targetAgents.length`. `plan.targetAgents` is `config.agents ∩ SUPPORTED_AGENTS` with no detection fallback, while the producer resolves consumer targets through `DetectionService` fallback; raw agent counting therefore does not represent producer eligibility (the invalid oracle below is the observed proof).
- Did **not** broaden agent resolution or refactor the producer/plan resolver.
- Retained preserved behavior:
  - enabled-producer fail-closed: with a loaded config, selected `workflowSources` remain required with exact path and staged-body digest;
  - explicit empty selection (`workflows: []`) yielding an empty required set;
  - custom overrides excluded from required membership;
  - prior-only catalog entries, provenance, native bindings, retirement, and atomic publication paths untouched.

### 2. `scripts/generation/isolated-stage.test.ts` — invalid oracle deleted

Removed `generation with zero agents and selected workflows does not require a workflow catalog` (previous lines 3798-3821). Its premise is false: the fixture directories detect `copilot` + `antigravity`, so `SyncService.resolveTargetAgents` resolves non-empty agents and the producer legitimately emits `workflowCatalog.workflows.demo`. The nonzero catalog in `eligibility-red.log` is the actual assertion diff for that test, not a source regression. It was deleted, not repinned; no detection fallback or defaults were changed to satisfy it.

Retained the valid no-config regression test `generation without config does not require a workflow catalog for local canonical workflows` unchanged (pre-change behavioral RED: `false !== true` at line 3793).

### 3. `.agent/sdd/critical-thinking-agent-workflows/final-eligibility-report.md` — this report.

## Evidence

- `eligibility-red.json` / `eligibility-red.log`: pre-source behavioral RED, exit 1, 2 tests / 2 failures.
  - Valid: no-config case returned `success === false` while the catalog producer is ineligible.
  - Invalid: zero-agent case published a legitimate `workflowCatalog` because the fixture detects consumer agents.
- `corrected-fixture-green.log` (parent, `bg6`): 7/7 strict/catalog controls PASS before this gate change; untouched by this delta.
- Corrected digest-drift fixture (entry + every native binding `canonicalDigest` mutually consistent, canonical bytes unchanged) untouched; no wording assertions re-added.

## Residual risks / parent-owned gates

- A config that loads but resolves zero consumer agents (no detection markers) would still fail closed, exactly as before this delta: the gate is config-presence based, while the producer additionally requires non-empty resolved agents. This is pre-existing strictness, unreachable in the observed fixture, and out of the authorized scope ("no broad resolver refactor"). Parent's focused GREEN and full generation/CLI/MCP suites should confirm the enabled-producer boundaries.
- Parent owns focused GREEN, full generation/CLI/MCP suites, actual same-root generation/MCP verification, independent source/delivery review, docs, and scoped audit updates. Human acceptance/release pending.
