# Task 2 report — Trace and outcome compatibility

- Status: **FINAL** (implementation complete; frozen for parent GREEN)
- Task number: 2
- Packet: `.agent/sdd/critical-thinking-agent-workflows/task-2-brief.md`
- Plan SHA-256: `3f8507032f034b8b04b6bdb509e3af46aea616cb22acc609d48e6cbdedc5db3d`
- Source revision: `1c79a7edb22b768ad5362e2e10766df2978e8642`
- Workspace: `<CHECKOUT>`
- Parent RED checkpoint: `.agent/sdd/critical-thinking-agent-workflows/red-reporting.log` / `red-focused.json` — 92 tests, 85 pass, 7 fail; classified `expected_red` (predicted namespaced canonical/schema/graph/scope cases failed; historical/source guards passed).

## Files changed

| Path | Change |
| --- | --- |
| `scripts/trace/types.ts` | `ID_GRAMMAR` extended to numeric `P-[0-9]{3,}` **or** uppercase namespaced `P-[A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*-[0-9]{2}`; `QUALIFIED_ID_GRAMMAR` / `QUALIFIED_NAMESPACE_GRAMMAR` unchanged. |
| `scripts/trace/parse.ts` | Occurrence validity now applies source-context precedence `isMappedSource ? isQualifiedId : declaration ? isFormal \|\| isQualifiedId : isFormal \|\| isQualifiedId \|\| isQualifiedNs`. Source detection, mapping extraction, `qualified` calculation and table/header semantics untouched. |
| `scripts/outcome/schema.ts` | Imports the pure `ID_GRAMMAR` from `../trace/types`; `TRACE_ID_PATTERNS` maps the four trace arrays to their kind patterns instead of duplicating regexes. |
| `scripts/trace/parse.test.ts` | Replaced one conflated test with two role-specific ones; added one canonical-grammar test. |
| `scripts/trace/graph.test.ts` | Replaced one conflated test with a role-specific one; added one canonical-declaration graph test. |
| `scripts/trace/index.test.ts` | Replaced one conflated CLI test with two scoped tests (required-scope pass, source-context fail-closed). |
| `scripts/outcome/schema.test.ts` | Added acceptance test for approved namespaced IDs and rejection matrix for historical/lowercase/undersized/wrong-kind IDs. |
| `scripts/outcome/index.test.ts` | Added required-scope acceptance for namespaced IDs and rejection of a namespaced three-digit source ID. |
| `.agent/sdd/critical-thinking-agent-workflows/task-2-report.md` | This report. |

Frozen test-stage digests (unchanged since TESTS_READY): `parse.test.ts` `3fc10415e3c3870fff641966ae9b980d1379ca9a1ce68d271f85815d14657348`, `graph.test.ts` `488855cc8c884c3f7a49d05bc56e0d1396d44304f9f3946a27c817b2dec9179b`, `index.test.ts` `f26c6b5ae6170df1bd530d2f6f770e28943f7af889df967e1b55c92f035c6eaa`, `schema.test.ts` `a66395b3ab7cc775c3b81fe21f2d12d01e39df14b403437109cd53920b07244e`, `outcome/index.test.ts` `f072ae4ed819ee20817438e5a86bedb8c04710f7755a3afad9f0ff4b3a80ba08`.

Implementation-stage digests: `types.ts` `974ad6a7f7a78734102fb7256990d8e98f18f3f33d6a07b877cb6cfad5f0fe94`, `parse.ts` `1d13089f1efe3fad45ac163c6236d886b0c29504e13604bf927c1080bddce585`, `outcome/schema.ts` `31ce8588096f6214c3fec355d6242cdbdeb1c449ae039d09ee7c17b5ac56974a`.

## Contract implemented (tests and code)

From SRS LLD-CT-03 / ADR-CT-01 (not restated or narrowed):

- numeric formal `P-[0-9]{3,}`; namespaced formal `P-[A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*-[0-9]{2}` (exactly two digits);
- historical qualified REQ/AC `P-<NAMESPACE>-[0-9]{3,}` stays a source role;
- occurrence validity precedence `isMappedSource ? isQualifiedId : declaration ? isFormal || isQualifiedId : isFormal || isQualifiedId || isQualifiedNs`;
- recognized source headers only: `Source`, `Source group`, `Candidate requirement`; no `Source ID` support, no aliases, no case folding.

## Tests: intent / fault / oracle

### `scripts/trace/parse.test.ts`

1. **NEW** `canonical formal grammar accepts numeric and namespaced exactly-two-digit declarations`
   - Intent: a heading, an ID field, a formal table cell and an `SRS ID` table cell each declare `BRD-OBJ-CT-01`, `REQ-CT-01`, `AC-CT-01`, `SRS-CT-01` as canonical IDs.
   - Fault caught: today all four are `valid: false` because `ID_GRAMMAR` is numeric-only, so approved IDs never enter `declared`.
   - Oracle: SRS LLD-CT-03 grammar block and example list; `declared` membership plus `valid === true` and `qualified === false`.
   - RED checkpoint: **RED**. Post-fix: expected green.

2. **REPLACED** `parseRepo marks qualified IDs with undersized, missing, or nonnumeric terminal suffix as invalid` → `namespaced IDs are role-specific: two digits are formal while three digits stay historical sources`
   - Intent: in a formal `Req ID` column, `REQ-PILOT-01` is a canonical declaration, `REQ-PILOT-001` a historical source declaration, `REQ-PILOT`, `REQ-PILOT-EXTRA`, `REQ-ct-01` invalid.
   - Fault caught: the old test forced `REQ-PILOT-01` to be invalid in a declaration column, which the exactly-two-digit formal extension reverses; keeping it would forbid the approved grammar.
   - Oracle: LLD-CT-03's two-grammar split plus ADR-CT-01 disjointness; observed via `declared` vs `sourceDeclared` and `qualified`.
   - Expected now: **RED** on the `REQ-PILOT-01` assertions; `REQ-PILOT-001` assertions pass today and must keep passing.

3. **NEW** `recognized source contexts reject two-digit canonical-looking IDs and retain mapping diagnostics`
   - Intent: `REQ-CT-02` in a `Candidate requirement` table, `REQ-CT-01` in a `Source` column and `AC-CT-01` in a `Source group` column are invalid historical sources, enter neither declaration set, and the `REQ-CT-01 → REQ-001` mapping is still extracted.
   - Fault caught: post-extension, an implementation that checks `isFormal` before `isMappedSource` would mark these valid and (in the declaration-role case) manufacture canonical scope; dropping the mapping would hide the diagnostic.
   - Oracle: LLD-CT-03 `isMappedSource ? isQualifiedId` precedence and "retain … historical mapping extraction (including malformed candidates)".
   - RED checkpoint: green guard; must stay green post-fix (precedence guard).

### `scripts/trace/graph.test.ts`

4. **REPLACED** `… undersized, missing, or nonnumeric terminal suffix despite matching declaration+mapping` → `buildTraceGraph treats namespaced two-digit IDs as malformed sources but canonical declarations`
   - Intent: the same `REQ-PILOT-01` token is canonical in the BRD `Req ID` column and `malformed-id` in the PRD `Source` column; `REQ-PILOT` and `REQ-PILOT-EXTRA` stay malformed everywhere.
   - Fault caught: the old test asserted `malformed-id` for the declaration-column occurrence too, conflating the two roles.
   - Oracle: LLD-CT-03 precedence; asserted per `file` so the two occurrences are distinguished.
   - Expected now: **RED** (the "no malformed in the BRD file" assertion fails).

5. **NEW** `buildTraceGraph accepts canonical namespaced two-digit declarations without inventing errors`
   - Intent: a fully linked `BRD-OBJ-CT-01 → REQ-CT-01 → AC-CT-01 → SRS-CT-01` slug produces zero error-severity issues.
   - Fault caught: the numeric-only grammar turns every namespaced ID into `malformed-id`; a too-loose fix could instead create duplicate/dangling/orphan errors.
   - Oracle: LLD-CT-03 "Existing graph logic continues exact-ID comparison … fail-closed required REQ/AC scope".
   - RED checkpoint: **RED**. Post-fix: expected green.

### `scripts/trace/index.test.ts`

6. **REPLACED** `run() fails on a slug when mapped source ID has an undersized numeric suffix` (two tests):

   6a. **NEW** `run() passes --required on canonical namespaced two-digit REQ and AC declarations`
   - Intent: `--slug namespaced --required` exits 0 with only namespaced two-digit canonical declarations present.
   - Fault caught: today both IDs are invalid, `declared` is empty and the run fails with `empty-scope` + `malformed-id`.
   - Oracle: LLD-CT-03 grammar; `--required` demands one declared REQ and AC (`index.ts`).
   - RED checkpoint: **RED**. Post-fix: expected green.

   6b. **NEW** `run() --required cannot be satisfied by IDs that only appear in recognized source contexts`
   - Intent: `REQ-CT-01` under `Candidate requirement` and `AC-CT-01` in a source-only table yield `empty-scope` and retain the `REQ-CT-01` malformed diagnostic.
   - Fault caught: without source-context precedence both tokens become valid declarations and manufacture REQ/AC scope.
   - Oracle: LLD-CT-03 precedence + "enter neither declaration set"; SRS-CT-05 fail-closed scope.
   - RED checkpoint: green guard; must stay green post-fix (fail-closed guard).

### `scripts/outcome/schema.test.ts`

7. **NEW** `validateRunRecord accepts approved namespaced two-digit formal IDs`
   - Intent: `BRD-OBJ-CT-01` / `REQ-CT-01` / `AC-CT-12` / `SRS-CT-01` in their exact arrays validate with zero issues.
   - Fault caught: `TRACE_ID_PATTERNS` duplicates the numeric-only grammar, so approved IDs are rejected.
   - Oracle: LLD-CT-03 "outcome imports only the pure types/constants module" + SRS-CT-06 RunRecord v1 shape.
   - RED checkpoint: **RED**. Post-fix: expected green.

8. **NEW** `validateRunRecord rejects historical, lowercase, undersized, and wrong-kind namespaced IDs`
   - Intent: `REQ-DISC-001`, `REQ-CT-001`, `REQ-CT-1`, `REQ-ct-01` rejected in `requirements`; `REQ-CT-01` rejected in `acceptance_criteria`; `AC-CT-01` rejected in `requirements`.
   - Fault caught: widening to "two or more" digits, case-folding, aliasing, or dropping the per-field kind check while sharing one grammar.
   - Oracle: ADR-CT-01 exactly-two-digit disjointness; LLD-CT-03 "Retain field-specific kind checks".
   - RED checkpoint: green guard; must stay green post-fix.

### `scripts/outcome/index.test.ts`

9. **NEW** `required scope accepts a record tracing approved namespaced two-digit IDs`
   - Intent: `validateRunRecords` with the required scope returns exactly one match and zero issues for a namespaced-ID record.
   - Fault caught: validator grammar rejects the record, so it is "not schema-valid" and cannot satisfy scope.
   - Oracle: SRS-CT-06 truthful scoped receipt over the approved grammar; SRS-CT-05.
   - RED checkpoint: **RED**. Post-fix: expected green.

10. **NEW** `a namespaced three-digit historical source ID cannot satisfy required scope`
    - Intent: `REQ-DISC-001` in `requirements` yields zero matches and a schema-invalid issue.
    - Fault caught: reinterpreting three-digit namespaced IDs as canonical when widening the grammar.
    - Oracle: ADR-CT-01 "these sets stay disjoint"; LLD-CT-03 "they do not become formal".
    - RED checkpoint: green guard; must stay green post-fix.

## Implementation (FINAL stage)

1. **`scripts/trace/types.ts` — canonical pure source.**
   `ID_GRAMMAR[kind]` is now `^P-(?:\d{3,}|[A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*-\d{2})$` for each `P` in `BRD-OBJ`, `REQ`, `AC`, `SRS`; anchored and case-sensitive. `QUALIFIED_ID_GRAMMAR` keeps `\d{3,}`; `QUALIFIED_NAMESPACE_GRAMMAR` untouched. Two-digit namespaced formal and three-or-more-digit namespaced historical IDs are therefore disjoint, with no alias or normalization path.
   `xd://lsp` reported "No language server found", so the exported-constant reference check fell back to an exact text scan: `parse.ts:218` (only consumer of `ID_GRAMMAR`), `outcome/schema.ts` (before the change, its own literal copy), doc comments in `types.ts`, and an independent local `ID_GRAMMAR` in `skills/product-management/product-evidence/scripts/validate-product-evidence.mjs` that is not this constant and stays untouched. `graph.ts:146` consumes `QUALIFIED_ID_GRAMMAR` only and is unchanged.

2. **`scripts/trace/parse.ts` — source-context precedence.**
   Occurrence validity is `isMappedSource ? isQualifiedId : role === "declaration" ? isFormal || isQualifiedId : isFormal || isQualifiedId || isQualifiedNs`. `isMappedSource` detection, source-only declaration roles, mapping extraction (including malformed candidates), `qualified` calculation, table/header recognition (`Source`, `Source group`, `Candidate requirement` only) and graph semantics are unchanged.

3. **`scripts/outcome/schema.ts` — reuse the pure grammar.**
   `import { ID_GRAMMAR } from "../trace/types"`; `TRACE_ID_PATTERNS` maps `brd_objectives → ID_GRAMMAR["BRD-OBJ"]`, `requirements → REQ`, `acceptance_criteria → AC`, `srs → SRS`. Field-specific kind checks and placeholder checks retained; no `fs`/`path` dependency added to the pure module. `checkAssertion`-style unrelated code untouched.

No other component, doc, generated artifact or skill script was modified.

## Verification

- Worker-executed checks: **NOT RUN** (packet forbids tests/build/lint/format/generation by the worker; no test command was executed).
- Parent command, after this freeze:
  `rtk proxy node --import tsx --test scripts/outcome/schema.test.ts scripts/outcome/index.test.ts scripts/trace/parse.test.ts scripts/trace/graph.test.ts scripts/trace/index.test.ts`
- Expected GREEN: all 92 tests — the 7 previously RED cases (parse 1–2, graph 4–5, index 6a, schema 7, outcome 9) plus the 85 that already passed.
- Specific post-fix behavior to confirm at GREEN:
  - `REQ-001` and `REQ-CT-01`/`AC-CT-12`/`SRS-CT-01`/`BRD-OBJ-CT-01` are canonical (`declared`, `qualified === false`, schema-valid).
  - `REQ-PILOT-001`/`REQ-DISC-001` remain historical sources (`sourceDeclared`, `qualified === true`, schema-invalid in run records).
  - Two-digit namespaced IDs in `Source`/`Source group`/`Candidate requirement` contexts are `valid: false`, enter neither declaration set, emit `malformed-id`, and do not satisfy `--required`.
  - Numeric legacy roles unchanged, including `REQ-1`/`AC-01` still malformed and numeric IDs in `Source` columns still references with no mapped-source extraction.

## Limits and open risk

- RED was observed by the parent, not by this worker; GREEN is likewise parent-owned. The digests above are the frozen state to check.
- Tests assert observable roles (`declared`, `sourceDeclared`, `sourceMappings`, `valid`, `qualified`, issue codes, exit codes). No source-text assertions were added.
- Old tests that conflated newly formal two-digit IDs with historical roles were replaced by role-specific cases, not re-pinned: `parse.test.ts` "undersized suffix", `graph.test.ts` "undersized … despite matching declaration+mapping", `index.test.ts` "undersized numeric suffix". All other existing tests are untouched and remain justified.
- `Source ID` header support is deliberately not implemented or asserted; unrecognized headers are not used as evidence of source-context safety.
- Bounded scope: 11 distinct behavior cases; no exhaustive crossproduct matrix and no source-wording assertions. Priority order per instruction: exact preserved IDs (tests 1, 4, 5, 7, 9), recognized historical-source role safety (tests 2, 3, 4, 6b), required-scope exactness (6a, 6b, 9, 10), backward compatibility (test 8 and every untouched existing test).
- Reversal boundary: removing the exactly-two-digit namespaced formal support after downstream records adopt it requires a reviewed migration (ADR-CT-01), not a blind rollback.
- Frozen: no further writes to owned paths; FINAL.
