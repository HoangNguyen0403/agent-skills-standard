# Task 3 report — Canonical decision/evidence guidance

- Status: **FINAL_FROZEN** (owned paths frozen; corrective review applied in the single authorized follow-up)
- Task number: 3
- Packet: `.agent/sdd/critical-thinking-agent-workflows/task-3-brief.md`
- Plan SHA-256: `3f8507032f034b8b04b6bdb509e3af46aea616cb22acc609d48e6cbdedc5db3d`
- Source revision: `1c79a7edb22b768ad5362e2e10766df2978e8642`
- Workspace: `<CHECKOUT>`
- Profile basis: DeepSeek fallback after observed Flash 503 exhaustion; no premium call, no new spend.

## Files changed

| Path | Change | Size after |
| --- | --- | --- |
| `skills/common/common-decision-discipline/SKILL.md` | Four rule additions (fact/conflict preservation, summary provenance, claim binding), one proportionality line, one reference link; four existing bullets merged for token economy with no rule dropped. | 99 lines (limit 100) |
| `skills/common/common-decision-discipline/references/decision-evidence-fidelity.md` | New. Manual rubrics R1–R5, preference-versus-premise pair table, supplied-versus-inferred table, quoted/negated/adopted instruction table, oracle and reviewer-independence table, summary-laundering table, evidence-limit table, explicit non-goals. | 87 lines |
| `.agents/workflows/code-review.md` | Step 4: inspected-versus-claimed evidence boundary. Step 5: `APPROVE` scope and non-claims (finite/lexical/schema checks, sibling-agent or model agreement). | 67 lines (limit 80) |
| `.agents/workflows/verify-work.md` | Step 4: criterion-bound receipts (criterion, actual output, independent expected-behavior basis, unverified boundary) and `NOT RUN`/not-assessed lane reporting; finite-check non-claims. | 72 lines (limit 80) |
| `.agent/sdd/critical-thinking-agent-workflows/task-3-report.md` | This report. | — |

Not touched: `docs/`, `evals/evals.json`, `scripts/`, `skills/metadata.json`, any generated native mirror, any changelog. No tests, build, lint, format, generator or install command was executed.

## Sources read

- `docs/prd/prd-critical-thinking-agent-workflows.md` — REQ-CT-01/02/03 and AC-CT-01/02/03/05/06/07/08/09/10/11 (not restated, not narrowed).
- `docs/srs/srs-critical-thinking-agent-workflows.md` — HLD-CT-01, LLD-CT-01, SRS-CT-01/02/04/07/08; the "no new universal response schema", "reuse existing independent-oracle/actual-diff/reviewer-provenance rules" and low-risk-reuse constraints are carried from LLD-CT-01.
- `docs/adr/adr-critical-thinking-evaluation-contract.md` — finite scoring separate from semantic adjudication; no new scorer, judge or semantics version.
- `docs/srs/srs-walkthrough-critical-thinking-agent-workflows.md` — VER-CT-01/03 packet definitions (this task produces guidance those packets will later review; it does not claim them).
- `skills/common/common-tdd/SKILL.md` — oracle and independent-review contract reused by link, not duplicated.
- `skills/common/common-code-review/SKILL.md`, `references/orchestration.md:55-71` — reviewer independence and provenance; referenced, not restated.
- `.agents/workflows/code-review.md`, `.agents/workflows/verify-work.md`, `CONTRIBUTING.md:60-140` (skill/workflow authoring: ≤100-line skills, <80-line workflows, references for heavy content).

## Criterion mapping (manual-contract lane; not self-certified)

| AC | Guidance artifact | What a reviewer can now compare |
| --- | --- | --- |
| AC-CT-02 | SKILL §2 bullets 2–3; reference "Supplied versus inferred" | Supplied values and relationships preserved; a shifted value under "You said" is explicitly a failure |
| AC-CT-03 | SKILL §3 bullet 5; `verify-work` step 4 bullets | Claim names criterion, actual output, independent expected-behavior basis, unverified boundary |
| AC-CT-05 | reference "Preference versus premise" (A1/A2 opposing preference; B/D correct premise; C incorrect premise) | Verdicts follow evidence; agreement and contrarianism both rejected |
| AC-CT-06 | SKILL §1 proportionality bullet; reference cross-links to `common-tdd`/`common-code-review`; no new workflow, field or gate added | Reuse is by link; review can diff the four paths only |
| AC-CT-07 | `verify-work` step 4 bullet 3; reference "Evidence limits in reports" | Offline control, live behavior, consumer operation and human outcomes are separate; unperformed = `NOT RUN` |
| AC-CT-08 | SKILL §2 bullet 3 | Both positions kept with source and owner; only the affected decision routed |
| AC-CT-09 | SKILL §3 bullet 4; reference "Summary laundering" | Summary origin and uncertainty preserved; no promotion to `confirmed` |
| AC-CT-10 | reference "Evidence limits in reports" rows 1 and 4; `code-review` step 5 | Measured envelope and ungraded behavior named; record schema/identity audit is not trace membership; no semantic-safety or efficacy claim |
| AC-CT-11 | SKILL §1 proportionality bullet; `verify-work` step 6 unchanged | Low-risk in-chat path retained with no added artifact, quiz, reviewer round or approval |
| AC-CT-01 | Inventory below | Each practice has an evidence-linked disposition and a bounded search note |

AC-CT-04 and AC-CT-12 belong to T2 and integration; this task makes no claim about them.

## Practice inventory — existing / partial / proposed / deferred

Evidence tags follow the ledger convention. `confirmed(...)` names what was actually inspected in this task; BRD E-numbers are reused, not re-derived.

| Practice | Disposition | Evidence | Bounded-search limitation |
| --- | --- | --- | --- |
| Said-versus-assumed write-back | existing (labels) / proposed (value preservation) | confirmed(BRD E1); confirmed(`skills/common/common-decision-discipline/SKILL.md` §2 pre-change); labels-only eval: confirmed(BRD E6, `evals/evals.json:43-80` inspected) | Only this skill and its evals inspected; other consumers of write-back were not searched |
| Evidence tagging `confirmed/assumed/unknown` | existing | confirmed(BRD E1); confirmed(`references/evidence-ledger.md`) | — |
| Search-absence versus absent capability | existing | confirmed(existing SKILL anti-pattern) | Not checked in other skills that make absence claims |
| Unresolved-conflict retention and routing | partial → proposed | confirmed(`verify-work` step 5 covers scope drift only; no decision-discipline rule existed) | Other conflict-handling guidance not searched |
| Original-source provenance through summaries | partial → proposed | confirmed(E1 tags exist, no summary rule); confirmed(SKILL §3 pre-change) | No repository-wide search for summary-handling text |
| Completion-claim binding (criterion, actual output, oracle basis, boundary) | partial (PASS/BLOCKED separation) → proposed (receipt content) | confirmed(BRD E4, `verify-work` step 4 pre-change) | — |
| Independent test oracle | existing, reused by link | confirmed(BRD E2, `common-tdd` oracle field) | — |
| Reviewer independence and provenance | existing, reused by link | confirmed(BRD E3, `common-code-review/references/orchestration.md:55-71`); confirmed(`code-review` step 4 pre-change) | Host-control enforcement not inspected (no CI/branch-protection check performed) |
| Finite whole-answer/decision controls | existing with known limit; changed by T2, not T3 | confirmed(BRD E6/E7/E8); `evals.json` unchanged here | Production scorer not executed |
| Semantic rubric for paraphrase, quotation, negation, preference | proposed (this reference) | new artifact; aligned to LLD-CT-01/HLD-CT-02 | Development examples only; no held-out set |
| Low-risk in-chat path without new artifacts | existing, explicitly preserved | confirmed(BRD E1 Low-Risk Maintenance; `verify-work` step 6) | — |
| Universal critical-thinking workflow, mandatory quiz, global response field, automatic model judge | excluded | confirmed(PRD scope containment; ADR rejected alternatives) | — |
| Human comprehension and skill retention | deferred (BRD slices 2–3) | confirmed(PRD deferred, BRD E11 bounded search, E14–E17) | Not measured; no evaluator exists |
| Live efficacy / held-out paired measurement | deferred, unauthorized | confirmed(SRS-CT-08; walkthrough VER-CT-07 `NOT RUN`) | No baseline, no live calls |
| Native mirrors, docs, changelog, consumer discovery | deferred to integration owner | confirmed(mirrors exist at `.agents/skills/`, `.claude/skills/`; unchanged) | Mirror contents not edited or regenerated |

## Corrective review applied (single authorized follow-up)

| # | Defect | Correction |
| --- | --- | --- |
| 1 | Reference quoted-command row rated "Safe" on attribution alone | Verdict is now "Unsafe unless verified scoped deployment authority exists"; reason states attribution is not authority, an immediate command invites bypass, and safety requires separate verified deployment authority with no bypass recommendation. Closing rule states attribution never establishes authority. |
| 2 | Evidence table claimed a schema/scope audit establishes trace membership validity | Establishes only record shape plus exact `slug`/`workflow`/`run_id` identity match; explicitly does not establish that trace members are the approved requirement set, nor execution truth, approval, freshness or semantic completeness. |
| 3 | SKILL claim-binding rule read as applying to every claim | Scoped to **consequential** completion claims, preserving the proportionate low-risk path (SRS-CT-01/CMP-CT-01). |
| 4 | Supplied-versus-inferred examples lacked the given source facts | Added the supplied set (owner Maria; 15% of new signups via referral by 2026-12-31; $5k/month) above the table, and both safe rows now preserve the exact date and budget, grounding the omission verdict. |

No other path, rule, criterion or scope changed. Line counts after correction: SKILL 99, reference 87, `code-review` 67, `verify-work` 72.

## Semantic limits and non-claims

- The reference scenarios are development examples with independently stated expected dispositions. They are **not** the frozen held-out efficacy set, not a scored run, and not evidence of live model behavior.
- No automatic judge was added; semantic adjudication still requires a reviewer independent of implementation. Model or sibling-agent agreement is critique, not approval.
- Passing the finite controls (T2) remains a response-contract result. This task adds no claim of semantic safety, live efficacy, consumer operation or human comprehension.
- Human acceptance and release authority are unchanged and unclaimed; this report is a worker receipt, not independent review.
- Merged bullets in `SKILL.md` preserve every pre-existing rule; only wording was compressed. No rule was deleted, softened or made optional.

## Verification

- Worker-executed tests/build/lint/format/generation: **NOT RUN** (packet forbids them; scripts remain disabled).
- Worker-executed static checks: line counts only — `wc -l` gave 99 / 67 / 72, within the 100-line skill and 80-line workflow conventions.
- Parent verification (after freeze): independent semantic review of the four paths against the PRD/SRS and the reference rubrics, then real local MCP body/reference fetch of `common-decision-discipline` after integration regenerates mirrors. Expected: SKILL body and new reference resolve; no path or link mismatch.
- Integration obligations handed off: regenerate native mirrors through the normal generator, update docs/changelog for delivered behavior only, run consumer discovery and record exact changed-resource inventory.

## Freeze

All four owned guidance paths are frozen. No commit, push, install, generation or remote action was performed. Corrections require a new packet revision.
