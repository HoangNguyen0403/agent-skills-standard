# Catalog repair receipt — Task 1

- Status: **FINAL_FROZEN**
- Packet: `.agent/sdd/critical-thinking-agent-workflows/catalog-repair-packet-v2.md`
- Plan: `.agent/sdd/critical-thinking-agent-workflows/catalog-repair-plan.md` (56dfa60c…)
- User clarifications applied: schema `provenance:{kind:'local-authoring'}` only, remote entry shape unchanged, mixed/null/unknown rejected by CLI producer-validator and MCP consumer; no redundant cases; older consumers that reject the local variant stay unweakened (compatibility limit documented, not patched).
- Parent RED evidence (raw `repair-red-{cli,mcp,generation}.json/.log`): CLI 48 tests / 46 pass / 2 fail (local round-trip, mixed accepted); MCP 24 / 22 / 2 (local entry `unavailable`, mixed `managed`); generation 4 / 2 / 2 (catalog-only bootstrap not published, changed local bytes retained the old pin); both invariants green. No infra failure. Source edits below were made only after that release.
- Parent correction RED (raw `correction-red.json/.log`): `EXPECTED_RED` for T9/T10/T11 — 3 tests, 0 pass, 3 fail, each actual `--check` returned success where refusal is required; no setup error. The correction source below was released only after that observation.

## Production source changes (post-RED release)

- `cli/src/services/LockfileService.ts`
  - `WorkflowCatalogWorkflow`: `registry`/`requestedRef`/`resolvedCommit` optional; new `provenance?: { kind: 'local-authoring' }`.
  - `assertWorkflowCatalog`: exclusive variants. `provenance` present → must be exactly one key with `kind === 'local-authoring'` and no remote fields; absent → existing remote field checks unchanged. Mixed/null/unknown throw.
  - Path containment, canonical name, digest, binding canonical-digest/alias and conflict checks untouched.
- `mcp/src/services/WorkflowIndex.ts`
  - `catalogError`: same exclusive variant split; no relaxation of path/digest/binding/conflict checks, no fallback on bad metadata.
- `cli/src/services/SyncService.ts`
  - `completeInstall` accepts optional `workflowProvenance: 'local-authoring'`; remote callers omit it and keep today's attribution.
  - `buildWorkflowCatalog`: unchanged prior digest keeps the prior provenance representation verbatim (local attestation or remote fields); changed/new bytes with local origin emit only `provenance:{kind:'local-authoring'}`; changed/new bytes without a local origin keep the existing remote fields.
- `scripts/generate-indices.ts`
  - Local sync declares `workflowProvenance: 'local-authoring'` (its bodies are read from this checkout).
- `scripts/generation/isolated-stage.ts`
  - `verifiedStageCatalog`: keeps only staged entries whose canonical bytes still match the recorded digest (no claim for absent content).
  - `mergeWorkflowCatalog`: unchanged verified entries keep their prior record verbatim (provenance included); changed entries take the verified staged record; prior-only unrelated entries are retained.
  - `persistVerifiedOwnership`: bootstraps the catalog from the validated stage catalog when the prior lock has none, merges otherwise, then applies retirement reconciliation as before. `validateWorkflowCatalog` gates the staged catalog. Catalog-only change flows through the existing `lockContentIdentity` → atomic publish/verified-files path.
- Exported-symbol check: `xd://lsp` unavailable in this session; grep over `cli/src`, `mcp/src`, `mcp/test`, `scripts` covered `WorkflowCatalogWorkflow` and the three remote fields (consumers: `SyncService`, `isolated-stage`, tests; `UninstallService` only reads `path`/`nativeBindings`/`nativeConflicts`). No other caller reads the removed-required fields.

AC-CT-12 mapping: T1/T3/T5/T7 implement the positive contract; T2/T4/T8 implement the negative contract; T6 guards idempotence. AC-CT-07 remains evidence-truthfulness only (no claim added).

## Test files

- `cli/src/services/__tests__/LockfileService.spec.ts`
- `mcp/test/WorkflowIndex.spec.ts`
- `scripts/generation/isolated-stage.test.ts` (extended in the correction pass: fixture hook, T9–T11, T7 guard)

No other file was created or modified. `WorkflowCatalogInstall.spec.ts` (remote acquisition expectations) is untouched and unaffected: the local origin is opt-in.

## Correction pass (reviewer major: `--check` ignores lock-only staleness)

Production is **frozen and unchanged** since the previous FINAL_FROZEN. Only `scripts/generation/isolated-stage.test.ts` was edited: new fixture hook + three regressions + one existing-guard extension.

- Fixture hook: `FixtureOptions.stagedCatalogMutation?: 'drop' | 'digest'` implemented inside the existing `GENERATE_INDICES_WRAPPER` (env `FIXTURE_STAGED_CATALOG`). It rewrites the staged `.skills-lock.json` after the real producer ran — dropping the selected `demo` entry or replacing its canonical digest with zeros. Real producers/stage/publication remain in the loop; no mock echo.

### T9 — `--check` sees catalog-only staleness (AC-CT-12)

- name: `a catalog-only lock change fails --check without writing and passes after apply`
- contract: prior lock with `workflowCatalog` removed → `--check` fails with the stale-outputs diagnosis naming `.skills-lock.json`; every declared output and the lock are byte-identical afterwards and no lock publication temp survives. Apply succeeds and publishes the local-provenance `demo` entry; the next `--check` passes with the lock byte-identical.
- fault: check-only early return evaluates only generated outputs/retirements, so a lock-only defect passes while the strict consumer is unavailable.
- RED now: check returns success (assertion 1 fails).

### T10 — Required selected workflow missing from the staged catalog (AC-CT-12 negative)

- name: `check and apply refuse a selected workflow missing from the staged catalog`
- contract: prior catalog absent, staged catalog without the selected `demo` entry → `--check` and apply both fail with `Selected workflow "demo" is missing from the staged workflow catalog`; prior lock bytes and all declared outputs unchanged.
- fault: silent drop → empty catalog published, `--check` claims complete.
- RED now: `--check` passes and apply publishes an empty catalog.

### T11 — Required selected staged digest drifted (AC-CT-12 negative)

- name: `check and apply refuse a selected workflow whose staged catalog digest drifted`
- contract: staged `demo` digest zeroed → both `--check` and apply fail with `Staged workflow catalog digest for selected "demo" does not match…`; no publication, prior lock/output bytes unchanged.
- fault: `verifiedStageCatalog` silently filters the entry, so the run succeeds with incomplete coverage.
- RED now: `--check` passes and apply publishes without `demo`.

### T7 extension — prior-only stale entry is not blanket-validated

- `retained` prior-only entry now carries a deliberately stale digest while its file exists; generation must still succeed and keep the entry verbatim. Guards the boundary: required selected membership is validated, unrelated prior-only entries are neither validated nor pruned. Expected green before and after.

Design constraints accepted for the later source release (not implemented yet): required inventory from the configured selection (not surviving catalog/native outputs), explicit empty selection stays valid, semantic identity excludes `generatedAt`, candidate computation read-only, existing source/config/lock snapshot stability still gates apply, failure before publication.

### Correction source (implemented after `correction-red`)

- `GenerationPlan.workflowSources`: canonical `.agents/workflows/<name>.md` for exactly the configured selection, minus explicit `custom_overrides` (overridden bodies are user-owned and not generation membership). Empty selection ⇒ empty list. Computed in `buildGenerationPlan`; no other plan consumer changed.
- `buildCandidateLock(...)` extracted from `persistVerifiedOwnership`: same entry/source/catalog/`withSortedEntries` computation and the same `lockContentIdentity` comparison (timestamp excluded), now read-only and returning `{next, changed}`. `persistVerifiedOwnership` delegates, then keeps the unchanged atomic publish, drift re-checks, `onCommitted`/`onRenamed`, byte verification and temp cleanup.
- Required selected membership: the staged catalog is validated, then for each `plan.workflowSources` entry the stage must carry the exact canonical path and its digest must match the staged canonical body; otherwise the run fails with `Selected workflow "…" is missing from the staged workflow catalog.` / `Staged workflow catalog digest for selected "…" does not match its staged canonical body.` A absent staged catalog with a non-empty selection also fails. The assertion runs once before any retirement or output publication (check and apply alike) and again inside the candidate builder.
- `verifiedStageCatalog` still filters non-required staged entries only; prior-only entries remain retained verbatim and are never digest-validated or pruned.
- `--check` now computes the same candidate before its PASS/FAIL decision and treats `candidate.changed` as staleness, adding `• .skills-lock.json (ownership manifest or workflow catalog stale)` when no generated file is out of date. All existing source/config/lock stability assertions still run before the check decision; nothing is written on the FAIL path.

Focused correction commands (parent):

```bash
node --import tsx --test --test-name-pattern "catalog-only lock change|selected workflow missing|staged catalog digest drifted" scripts/generation/isolated-stage.test.ts
```

Full focused generation command for the covering suite remains:
`node --import tsx --test scripts/generation/isolated-stage.test.ts`

## Test intent records

### T1 — CLI accepts an explicit local-authoring entry (AC-CT-12)

- requirements: AC-CT-12; REQ-CT catalog provenance
- owner: catalog compatibility worker
- contract: a version-1 catalog entry shaped `{path,digest,provenance:{kind:'local-authoring'},nativeBindings:[…]}` (no `registry`/`requestedRef`/`resolvedCommit`) round-trips through `LockfileService.write` → `load` byte/field identical.
- fault: producer publishes the truthful local variant but the CLI validator still requires remote fields, so the lock write throws.
- layer: unit (real `LockfileService`, temp filesystem)
- cases: one local entry with one verified binding.
- oracle: `local-provenance-decision.json` (`local_entry_contract`) — approved requirement; not taken from implementation.
- boundaries: real fs + real validator; no mocks.

### T2 — CLI rejects mixed/unknown/null provenance (AC-CT-12 negative)

- contract: `write` rejects an entry that carries both `provenance` and remote fields, an unknown `kind`, or `provenance:null`.
- fault: permissive validation would let a fabricated or ambiguous trust claim into the published lock.
- cases: `it.each` strict rows — full mixed entry; each of `registry`/`requestedRef`/`resolvedCommit` present alone as `null` and as `""` beside local provenance (presence, not truthiness); `provenance:{kind:'local-authoring', extra:true}`; unknown kind; null provenance. A direct validator case covers an own `registry: undefined` property, which JSON cannot carry.
- oracle: clarification message (approved schema) + `local-provenance-decision.json` (`remote_fields` must be absent; unknown rejected).
- RED honesty: the original pre-implementation RED comprised the round-trip failure and the full mixed row (2 fails); the added singleton/extra rows are `NOT RUN` at RED and are post-RED strictness coverage.

### T3 — MCP serves a local-authoring catalog entry (AC-CT-12)

- contract: `lookupWorkflow` returns `status:"managed"`, exact body and configured digest, `nativeParity:true`, `parityIssues:[]` for a catalog whose entry only has local provenance.
- fault: consumer `catalogError` still requires `registry`/`requestedRef`, so real same-root generation stays unavailable.
- layer: unit/contract (real `lookupWorkflow`, temp project root)
- oracle: same approved local-entry contract; parity requires binding digests to match the files written by the fixture.
- boundaries: real lock parse, real path containment, real byte digests; no mocks.

### T4 — MCP fails closed on mixed/unknown/null provenance (AC-CT-12 negative)

- contract: `status:"unavailable"` with an `invalid` reason; never a fallback to `local_source`.
- cases: strict rows mirroring T2 — full mixed entry; each remote field alone as `null` and `""`; provenance `extra:true`; unknown kind; null. (An own `undefined` property is not JSON-representable, so it is not a consumer row.)
- RED honesty: the original RED comprised the local-entry `unavailable` and the full mixed row being `managed` (2 fails); the added singleton/extra rows are `NOT RUN` at RED.

### T5 — Source-root catalog bootstrap + real consumer (AC-CT-12 primary)

- contract: with a consumer lock whose `workflowCatalog` is absent, `runIsolatedGeneration` publishes a catalog whose `demo` entry has `provenance:{kind:'local-authoring'}`, no remote fields, canonical digest equal to the actual `.agents/workflows/demo.md` bytes, one or more bindings whose `outputDigest`/`canonicalDigest` match the real published files, records `.skills-lock.json` in `verifiedFiles` (catalog-only change counts), and the unchanged MCP `lookupWorkflow` serves `managed` + `# Demo` + `nativeParity:true`.
- fault: the wrapper reconciles only `previous?.workflowCatalog`, discarding the validated stage catalog, so a lock that never had a catalog stays without one and the strict consumer reports `no workflow catalog metadata`.
- layer: integration (real producers in an isolated stage + real publication + real MCP lookup). This is the producer→consumer regression oracle, not a mock echo.
- boundaries: real generation pipeline and real MCP service; no stubs.

### T6 — No churn after bootstrap (AC-CT-12)

- contract: a second generation on the bootstrapped repository leaves `.skills-lock.json` byte-identical.
- fault: catalog-only bootstrap that bypasses `lockContentIdentity` would rewrite/re-stamp the lock every run.

### T7 — Legitimate prior provenance survives (AC-CT-12 positive)

- contract: an unchanged prior remote entry (`demo`, digest matching) keeps its exact `registry`/`requestedRef`/`resolvedCommit`/bindings, and an unrelated prior entry (`retained`) is retained unchanged.
- fault: bootstrapping by replacing the catalog with the staged contents would restamp unchanged remote origin and drop unrelated entries.

### T8 — New local bytes never inherit the remote pin (AC-CT-12 negative)

- contract: after the authored canonical body changes, the regenerated `demo` entry carries `provenance:{kind:'local-authoring'}`, no remote fields, and the digest of the new bytes.
- fault: "preserve when unchanged" applied without the digest check would keep advertising `workflows-v1.0.0`/`abc123` for locally authored bytes.

## Exact focused commands (parent-run)

```bash
# CLI validator (whole catalog suite; matches T1/T2 plus existing fail-closed cases)
pnpm --dir cli exec vitest run src/services/__tests__/LockfileService.spec.ts

# MCP consumer (T3/T4 plus existing strictness cases)
pnpm --dir mcp exec vitest run test/WorkflowIndex.spec.ts

# Generation producer→consumer (T5–T8)
node --import tsx --test --test-name-pattern "consumer lock without a workflow catalog|bootstrapped catalog|unchanged remote catalog entry|new local canonical bytes" scripts/generation/isolated-stage.test.ts
```

Expected RED (observed and released by the parent; see the RED evidence line above):

- T1: `write` rejected the local entry (`registry`/`requestedRef` invalid provenance) → round-trip failed.
- T2: `mixed local and remote provenance` was accepted → expected rejection failed.
- T3: `lookupWorkflow` returned `unavailable` (`invalid provenance`).
- T4: `mixed local and remote provenance` was `managed`.
- T5: catalog absent after generation → bootstrap assertions failed.
- T8: regenerated entry kept no local provenance / failed the digest expectation.
- T6/T7 were green before and must stay green; they are guards, not RED evidence.

GREEN expectations after this release: all CLI/MCP suites green, generation pattern green with T5 publishing a local-provenance catalog, T8 replacing the remote pin, T6 byte-stable on repeat, T7 retaining prior remote + unrelated entries.

## Freeze

**FINAL_FROZEN.** All owned writes stop here. Nothing has been committed, pushed, or executed by this worker. Parent owns every runtime check, the real same-root MCP smoke, generation check, and independent review.

Post-RED test extension (earlier revision): strict singleton rows were added to T2 (CLI) and T4 (MCP) — `registry`/`requestedRef`/`resolvedCommit` present alone as `null` and `""`, provenance with `extra:true`, plus a direct CLI validator case for an own `registry: undefined`. These extend the strict-surface coverage; they did not exist at the original RED, which remains honestly reported as the original six failures. Implementation already checks own-property presence, not truthiness, so no source change accompanied them.

Correction pass: T9/T10/T11 and the T7 stale-prior-only guard were added before the correction RED; the shared read-only candidate extraction and required selected membership/digest validation were implemented only after `correction-red`. No test was weakened or added after that release.

## Evidence / limits

- `NOT RUN` by me: every test, build, lint, format, generator, JSON/regex check (per packet), including syntax validation of the edited sources. RED/GREEN classification and all GREEN claims belong to the parent's raw runner output.
- Not observed by me: the final same-root consumer result, stage publication, or real generation; those remain parent gates. The pre-repair failure is the recorded `consumer-generated.log` (`Installation lock has no workflow catalog metadata`).
- Review surfaces for the independent reviewer: (a) `mergeWorkflowCatalog` treats an entry as unchanged only when path, digest, bindings and conflicts agree, otherwise the verified staged entry wins; (b) bootstrap filters out staged entries whose canonical bytes do not match the recorded digest; (c) the local origin is opt-in on `completeInstall`, so remote acquisition attribution is byte-for-byte the previous behavior; (d) prior unchanged local/remote provenance is preserved verbatim, including the absence of fields.
- TS shape note (not refactored, per instruction): `WorkflowCatalogWorkflow` keeps remote fields and `provenance` as independently optional properties while the runtime validator enforces exclusivity. A discriminated union (`{provenance}` vs `{registry;requestedRef;resolvedCommit}`) would make that exclusivity compile-time; left as a maintainability review item rather than an unasked refactor.
- Known compatibility limit (documented, not patched): consumers built before the local variant reject such a catalog and stay fail-closed.
- Additional-file decision check: no path outside the owned write set was needed; `WorkflowSyncService` typing was not touched.
- Disclosure: before the no-command instruction was registered in this session I ran two read-only directory listings (`ls -la .agent/sdd/...` and `pwd; ls`). No tests, builds, generators, or writes were performed by them; all subsequent work used read/edit/write only.
