# Subagent-Driven Development (SDD) Methodology

## 1. Execution Confirmation Gate

### Scenario A: Post-Planning Handoff (`writing-plans`)
When an implementation plan has just been created or approved, confirm with the human partner before touching code:
> *"Plan complete and saved to `docs/...`. Which execution approach would you prefer?*
> *1. **Subagent-Driven (Recommended)** — Fresh worker per task for context isolation and task review gates.*
> *2. **Inline** — Direct implementation in this session (an explicit recorded exception suitable only for small, genuinely low-risk bounded changes; file count alone does not establish low risk).*
> *For this plan I recommend Subagent-Driven. Shall I proceed with subagents?"*

### Scenario B: Existing Plan or PR Ingestion (e.g. "implement this plan inside PR ...")
When a user opens a session or supplies an existing multi-task plan/PR:
1. **DO NOT start editing files directly in this session.**
2. Detect the multi-task scope and confirm:
> *"I found a multi-task implementation plan in <source>. To maintain task isolation and review gates across tasks, I recommend **Subagent-Driven** execution. Shall I dispatch via subagents or implement inline?"*
3. **Vague assent boundary:** Vague assent ("yes", "proceed", "start", "approve") binds ONLY the specific choice just presented. Approval of a brief or plan does not implicitly authorize inline execution, auto-promotion, premium escalation, or scope expansions.
4. Host/user retry, account, and profile rules override defaults. If Subagent-Driven is approved, immediately proceed with the SDD Task Loop.

## 2. SDD vs. TDD

- **SDD (Macro Workflow):** Decomposes plan into tasks, dispatches workers, generates review packages, verifies with independent reviewers, and logs progress to `progress.md`.
- **TDD (Micro Coding):** Follows the RED -> GREEN -> REFACTOR cycle inside each task. SDD mandates that every implementer subagent follows TDD within its assigned task brief.

---

## 3. The Task Loop & Worker Contract

1. **Record Baseline & Dispatch Implementer:**
   - Record baseline: `BASE=$(git rev-parse HEAD)`
   - Extract brief from the repository root: `python3 skills/common/common-subagent-driven-development/scripts/task_brief.py <PLAN_FILE> <TASK_NUMBER>`.
   - **Brief Contract Validation:** `task_brief.py` validates required contract fields: scope/owned write set, inputs, outputs, real ingress, positive/negative invariants, verification owner, explicit handoff/freeze (FINAL), and correction route. Historical plans lacking fields receive a clear error; `task_brief.py` refuses to overwrite existing output files.
   - **Conversion handoffs:** For cross-worktree or multi-artifact conversion tasks, include exact cross-worktree input paths, source/user/project-authored provenance, and inclusive ranges; preserve unaffected fields during correction.
   - Dispatch worker with `[BRIEF_FILE]` and `[REPORT_FILE]`.
   - **Worker Contract**: Worker owns bounded implementation and focused tests on touched files. Worker does NOT commit with Git, recursively delegate to subagents, or run full suites by default.
   - **Denial alternative versus total block:** A denied command or tool call is not an automatic total block if an allowed alternative or read-only inspection exists. Do not report "all tests blocked" when one specific command was denied.
   - **Sibling requests forward-only:** A sibling agent can forward a request to the orchestrator or human, but cannot approve, deny, or bypass permissions for another agent.
   - **Error is not terminal state:** Provider 429, timeout, or connection error is not proof that the agent turn is terminated or the previous writer has stopped. Acknowledge terminal state before transferring write ownership.
   - Call `wait()` once and yield control. Never poll `get_agent_status` or `get_agent_activity` in a loop.
3. **Scoped Review Package & Review:**
   - Generate scoped package from worker's owned paths:
     `python3 skills/common/common-subagent-driven-development/scripts/review_package.py <PLAN_FILE> $BASE WORKSPACE --paths <OWNED_PATHS...>` (explicit literal file paths or bounded owned directories only; no broad/magic scopes).
   - Dispatch reviewer with `[BRIEF_FILE]`, `[REPORT_FILE]`, and `[DIFF_FILE]`. Call `wait()`.
4. **Fix Loop & Failure Routing:**
   - **Active policy resolution:** Correction count, retry limits, and eligible implementation routes are resolved from active host/user policy, which overrides generic defaults.
   - **Quality failure vs. Quota failure:**
     - Quality failure (defective implementation, AC failure): Follow the active host/user policy for corrective turns (e.g. one bounded corrective follow-up with concrete findings under current session orchestration policy). If unresolved after authorized turns, escalate that slice to the next authorized implementation route per account policy.
     - Quota failure (429, usage limit, provider exhaustion): Advance immediately to the next authorized route for remaining slices; do not burn attempts or re-poll the exhausted provider.
     - Other provider runtime errors (glitches, timeouts, mid-turn disconnections): Confirm terminal state and writer acknowledgement before failover or transferring write ownership. Never auto-escalate to premium models without explicit human approval.
   - Re-generate an immutable cumulative package from the original `$BASE` and identical owned paths: `python3 skills/common/common-subagent-driven-development/scripts/review_package.py <PLAN_FILE> $BASE WORKSPACE --paths <OWNED_PATHS...>`. The default filename includes the package-content digest; each changed fix round is retained as a separate snapshot.
   - Re-review the open findings against the latest cumulative `BASE..WORKSPACE` state. This artifact is not a fix-only diff; report regressions in the cumulative task-owned result without claiming they were introduced only by the latest round.
5. **Orchestrator Integration:**
   - Orchestrator verifies diff, runs full suite regression checks if required by tier, and commits the task changes with git.
## 4. Final Review & Completion

Run whole-branch review:
```bash
python3 skills/common/common-subagent-driven-development/scripts/review_package.py <PLAN_FILE> $MERGE_BASE HEAD
```
Dispatch a senior reviewer on the most capable model.

**Workspace cleanup requires verified durable archive and ownership authority:**
Before deleting `<workspace>`, verify that all reports, diffs, receipts, and execution evidence are archived in a durable location outside the scratch directory. Never erase the only evidence copy. If archive verification fails or ownership authority is missing, retain the workspace and report the unarchived evidence. Once verified and authorized, delete `<workspace>` and complete the branch.
