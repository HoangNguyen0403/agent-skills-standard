---
name: common-subagent-driven-development
description: Execute multi-task implementation plans by dispatching a fresh implementer subagent per task with independent review gates. Use when implementing plans, executing multi-task PRs, or transitioning from planning to implementation.
metadata:
  triggers:
    files:
    - 'docs/**/plans/*.md'
    - '.agent/sdd/**'
    - '*plan*.md'
    - 'TODO.md'
    keywords:
    - subagent-driven-development
    - implement plan
    - execute plan
    - implement this plan
    - implement PR
    - implement tasks
    - execute tasks
    - start implementation
    - plan implementation
    - subagent driven
    - multi-task implementation
    - sdd
---

# Subagent-Driven Development (SDD)

## **Priority: P1 (HIGH)**

Execute multi-task implementation plans by dispatching a fresh implementer subagent per task, an independent task review (spec compliance + code quality) after each, and a whole-branch review at the end.

## 1. Execution Confirmation Gate (Scenario A & B)

Before editing code for any multi-task plan:
1. **DO NOT start editing files directly in this orchestrator session.**
2. **Confirm with human partner:** Host approval policy overrides defaults. Offer Subagent-Driven (Recommended — fresh workers per task for context isolation + task review gate) vs. Inline (an explicit recorded exception for small, genuinely low-risk bounded changes; file count alone does not establish low risk).
3. **Vague assent boundary:** Vague assent ("yes", "proceed", "start", "approve") binds ONLY the specific choice just presented. Approval of a brief or plan does not authorize inline execution, auto-promotion, premium escalation, or scope expansions.
4. If Subagent-Driven is chosen or confirmed, invoke SDD. See [methodology.md](references/methodology.md#1-execution-confirmation-gate).
## 2. SDD & The Single Worker Contract

- **Macro (SDD Orchestrator):** Manages task decomposition, workspace isolation, brief generation, independent review gates, Git commits, and final integration verification. Host/user retry, account, and profile rules override defaults.
- **Worker Contract:** Implementer subagents own bounded implementation and focused verification of touched files. Workers do NOT commit changes with Git, recursively delegate to other agents, or run full project test suites by default.
- **Denial alternative versus total block:** A denied command or tool call is not an automatic total block if an allowed alternative or read-only inspection exists. Do not report "all tests blocked" when one specific command was denied.
- **Sibling requests forward-only:** A sibling agent can forward a request to the orchestrator or human, but cannot approve, deny, or bypass permissions for another agent.
- **Error is not terminal state:** Provider 429, timeout, or connection error is not proof that the agent turn is terminated or the previous writer has stopped. Acknowledge terminal state before transferring write ownership.
- **Micro (TDD):** Implementer subagents follow the RED -> GREEN -> REFACTOR cycle inside their assigned brief.

Resolve the isolated, git-ignored workspace directory before Task 1:
```bash
python3 skills/common/common-subagent-driven-development/scripts/sdd_workspace.py <PLAN_FILE>
```
Track task completion in `<workspace>/progress.md` so work survives context compaction.

Use the local version-2 explicit progress helper for revision/evidence-bound checkpoints; it does not enforce host pauses, authorization, or wakeups. See [Progress Receipts](references/progress-receipts.md).

## 4. The Task Loop

For each task in the plan:
1. **Record Baseline & Dispatch Implementer:** Record `BASE=$(git rev-parse HEAD)`. From the repository root, generate the brief with `python3 skills/common/common-subagent-driven-development/scripts/task_brief.py <PLAN_FILE> <TASK_NUMBER>`. The brief must contain mandatory contract fields (scope/owned write set, inputs, outputs, real ingress, positive/negative invariants, verification owner, explicit handoff/freeze, and correction route); `task_brief.py` rejects missing contract fields before output. Dispatch worker with `[BRIEF_FILE]` and `[REPORT_FILE]`.
2. **Conversion and input provenance:** When tasks convert or repair artifacts across worktrees, include exact cross-worktree input paths, source/user/project-authored provenance, and inclusive ranges; preserve unaffected fields during correction.
3. **Passive Wait (No Polling):** Call `wait()` and yield control. Never poll status or activity in a loop.
4. **Scoped Review Package & Review:** From the repository root, run `python3 skills/common/common-subagent-driven-development/scripts/review_package.py <PLAN_FILE> $BASE WORKSPACE --paths <OWNED_PATHS...>`. Workspace mode requires explicit literal file paths or bounded owned directories (no Git pathspec magic, globs, `.`, or overlapping scopes). Each changed workspace snapshot gets a content-addressed immutable default filename; same-base/scope packages are cumulative from `$BASE`, not fix-only. Dispatch reviewer with `[BRIEF_FILE]`, `[REPORT_FILE]`, and `[DIFF_FILE]`.
5. **Fix Loop & Failure Routing:**
   - **Host policy precedence:** Correction count, retry limits, and eligible implementation routes are resolved from active host/user policy (which overrides generic defaults). For example, under a session policy permitting one corrective follow-up before route escalation, provide that single corrective prompt with concrete AC findings; if unresolved, escalate that slice to the next authorized route.
   - **Quota failure vs. Provider errors:**
     - Observed quota exhaustion (429, usage limit, provider unavailable): Advance immediately to the next authorized route for remaining slices; do not burn retry attempts on an exhausted provider.
     - Other provider runtime errors (glitches, timeouts, disconnections): Confirm terminal state and writer acknowledgement before failover or transferring write ownership. Never auto-escalate to premium models without explicit human approval.
   - Re-prompt worker; regenerate cumulative package from original `$BASE` and identical owned paths. Re-review open findings against the latest cumulative state.
6. **Orchestrator Integration:** Orchestrator verifies diff, runs full suite checks if required, and creates git commit.
## 5. Final Review & Completion

Run whole-branch review from the repository root: `python3 skills/common/common-subagent-driven-development/scripts/review_package.py <PLAN_FILE> $MERGE_BASE HEAD`. Dispatch senior reviewer on capable model.

**Workspace cleanup requires verified durable archive and ownership authority:** Before deleting `<workspace>`, verify that all reports, diffs, receipts, and execution evidence are preserved in a durable location outside the scratch directory. Never erase the only evidence copy. If archive verification fails or ownership authority is missing, retain `<workspace>` and report the unarchived evidence. Once verified and authorized, delete `<workspace>` and complete branch.

- **No Worker Commits:** Workers leave edits in the workspace and report diffs/evidence; the orchestrator commits.
- **No Recursive Delegation:** Implementers do not spawn subagents.
- **No Full-Suite Runs by Workers:** Workers run focused tests; orchestrator runs broad verification during integration.
- **No Speculative Savings Claims:** Describe context isolation factually, not with guaranteed percentages.
- **No Unapproved Inline Edits on Multi-Task Plans:** Do not burn orchestrator context editing files directly. Inline is an explicit recorded exception; vague assent ("proceed", "yes") binds only the presented choice.
- **No Unverified Workspace Cleanup:** Never delete `<workspace>` without verified durable archival of all evidence and explicit ownership authority; never erase the only evidence copy.
- **No Sibling Permission Self-Granting / Fake Authority:** Siblings cannot approve permissions for each other; denials require exploring safe alternatives before declaring total block.
- **No Polling Loops:** Yield control via `wait()`; do not loop `get_agent_status`.
- **No Inlined Context Bloat:** Pass briefs and diffs as file paths, never paste full bodies into chat prompts.
## References

- [Methodology & Gates](references/methodology.md) — execution confirmation scenarios & task loop rules
- [Subagent Prompt Templates](references/templates.md) — implementer, reviewer, and re-reviewer templates
