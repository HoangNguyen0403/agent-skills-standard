# Skill Testing, Trigger Rate & Regression Guide

## 1. Eval Set Schema

Save test cases to `evals/evals.json` next to `SKILL.md`:

```json
{
  "skill_name": "my-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "Realistic user task that should invoke this skill",
      "expected_output": "Description of what a correct response looks like",
      "assertions": [
        {
          "id": "a1",
          "description": "Output contains X",
          "type": "contains",
          "value": "X"
        }
      ]
    }
  ],
  "should_not_trigger": [
    "Near-miss prompt — shares keywords but needs a different skill",
    "Another near-miss prompt"
  ],
  "pressure_scenarios": [
    {
      "prompt": "High-pressure or shortcut-seeking prompt",
      "failure_mode": "How the agent is tempted to violate the rule",
      "behavior_assertions": ["Phrase or action the skill should force"]
    }
  ],
  "rationalizations": [
    "The excuse agents commonly use to skip the rule"
  ],
  "red_flags": [
    "Phrase that means stop and restart the protocol"
  ]
}
```

**Assertion types** (the runner accepts these five and nothing else — `scripts/evals/types.ts`):
`contains`, `contains_any`, `not_contains`, `regex`, `file_reference`.

An unknown type is not ignored: `scorer.ts` returns `false` for it, so the assertion fails on every
transcript and the case can never pass. `matches_regex` and `file_exists` do not exist.

- Write at least 3 `evals` with at least 2 assertions each; fewer is flagged by `pnpm evals:audit`.
- **Ground every assertion in the prompt plus `expected_output`**, never in `SKILL.md` alone. `pnpm evals:preflight` rejects skill-only assertions and blocks the paid run. Write the behavior contract first, then assert on its wording.
- Both `should_trigger` and `should_not_trigger` must be non-empty, or the audit errors with `missing-trigger-class`.
- Write 8–10 `should_not_trigger` entries. Focus on near-misses that share keywords but belong to a different skill.
- Add `pressure_scenarios` for discipline skills where agents rationalize shortcuts. Their prompts become real two-arm eval cases and their `behavior_assertions` are scored as `contains` against the transcript.
- Keep `rationalizations` and `red_flags` short; benchmark tooling reads them statically and never feeds them to a model.

### Testing a trade-off, not a vocabulary

A string matcher cannot grade judgment, but it can grade whether the answer **changes when the
constraint changes**. Pair a scale-up case with an inverted one in the same domain and use
`not_contains` to assert the over-engineered option is absent:

```json
{ "id": 4,
  "prompt": "Internal admin tool, 200 requests per second, two engineers. One page takes 4 seconds.",
  "expected_output": "Declines the cache because no component without a constraint is allowed; fixes the query first.",
  "assertions": [
    { "type": "contains_any", "value": ["no component without a constraint", "fix the query"] },
    { "type": "not_contains", "value": "consistent hashing" }
  ] }
```

A skill that always reaches for the same component passes the first case and fails the second.

## 2. Trigger Rate Queries

Trigger rate = % of should-trigger queries that correctly activate the skill.

### Should-Trigger (8–10 queries)

- Cover different phrasings: formal, casual, abbreviated, misspelled.
- Include cases where the skill name is never mentioned but context clearly requires it.
- Include uncommon but valid use cases.
- Add competition cases: queries where this skill must win over an adjacent one.

**Good**: `"ok so my boss gave me this ts file and it has like 5 different things going on in one class"`
**Bad**: `"Create a skill"` (too obvious, doesn't test anything)

### Should-Not-Trigger (8–10 queries)

- Focus on near-misses: share keywords but need a different skill.
- Adjacent domains, ambiguous phrasing, context where another tool wins.
- Do NOT use obviously unrelated queries — they don't test anything.

**Good**: `"review this PR and check if the architecture looks right"` (code-review skill, not skill-creator)
**Bad**: `"Write a fibonacci function"` (too far away, trivially fails)

### Scoring

Run each query, record `triggered: true/false`. The release gate in `scripts/evals/readiness.ts` requires **≥ 90%** recall and ≥ 90% specificity, so treat 90% as the target, not 80%.

## 3. Optimizing the Description for Triggering

The description field is the **primary trigger mechanism**. Agents decide whether to use a skill based solely on name + description.

### Rules

1. **Be "pushy"**: Explicitly list the contexts that should trigger, not just what the skill does.
2. **Include "when to use"**: Put all trigger context in the description, not in the body.
3. **Cover edge cases**: Add contexts the agent might miss (e.g., "even if the user doesn't say X explicitly").
4. **Use active verbs**: "Use this skill when..." > "This skill covers..."

### Before / After Example

```yaml
# Before (passive — undertriggers)
description: Standards for creating new High-Density Agent Skills.

# After (pushy — triggers reliably)
description: >
  Standards for creating, testing, and optimizing High-Density Agent Skills.
  Use this skill whenever creating a skill from scratch, improving an existing skill,
  measuring trigger accuracy, catching regressions, or optimizing a description
  so it triggers more reliably.
```

### Iteration Loop

1. Write 20 trigger queries (half should-trigger, half should-not-trigger).
2. Run each query and record results.
3. Identify which query types fail and why.
4. Rewrite the description to address the failures.
5. Re-run; repeat until ≥ 90% accuracy on held-out queries (matching release readiness: ≥90% recall and specificity).

## 4. Catching Regressions

When editing an existing skill, always compare before-and-after:

1. **Snapshot before editing**: `cp -r skills/common/my-skill /tmp/my-skill-snapshot`
2. **Edit the skill**.
3. **Re-run all existing evals** against the new version.
4. **Compare outputs**: Did any previously-passing assertions now fail?
5. **Fix regressions** before shipping.

### Regression Checklist

- [ ] All previously-passing eval assertions still pass.
- [ ] Trigger rate did not drop (re-run should-trigger set, verify ≥ previous score).
- [ ] SKILL.md still within size limits (< 100 lines).
- [ ] No new anti-patterns introduced (check `references/anti-patterns.md`).
- [ ] Guardrail skills still counter the same rationalizations after edits.
