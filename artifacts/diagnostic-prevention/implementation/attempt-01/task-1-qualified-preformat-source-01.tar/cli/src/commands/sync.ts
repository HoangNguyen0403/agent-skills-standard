import inquirer from 'inquirer';
import pc from 'picocolors';
import { Agent } from '../constants';
import { McpScope, SkillConfig } from '../models/config';
import { ConfigService } from '../services/ConfigService';
import { DetectionService } from '../services/DetectionService';
import {
  McpConfigService,
  defaultMcpConfig,
} from '../services/McpConfigService';
import { CLAUDE_MCP_PERMISSION, HookService } from '../services/HookService';
import { SyncService } from '../services/SyncService';
import { InstallPlan } from '../services/install/OwnershipWriter';

export interface SyncOptions {
  yes?: boolean;
  snippets?: boolean;
  dryRun?: boolean;
  force?: string[];
  verbose?: boolean;
  json?: boolean;
}

/**
 * Command for synchronizing skills and workflows from the remote registry to the local workspace.
 * It handles configuration re-detection, fetching files, writing to disk, and updating indices.
 */
export class SyncCommand {
  private configService: ConfigService;
  private detectionService: DetectionService;
  private syncService: SyncService;
  private mcpService: McpConfigService;
  private hookService: HookService;

  constructor(
    configService?: ConfigService,
    detectionService?: DetectionService,
    syncService?: SyncService,
    mcpService?: McpConfigService,
    hookService?: HookService,
  ) {
    this.configService = configService || new ConfigService();
    this.detectionService = detectionService || new DetectionService();
    this.syncService = syncService || new SyncService();
    this.mcpService = mcpService || new McpConfigService();
    this.hookService = hookService || new HookService();
  }

  /**
   * Executes the synchronization flow.
   * Reconciles dependencies, fetches skills and workflows from the registry, and updates AGENTS.md.
   */
  async run(options: SyncOptions = {}) {
    try {
      // 1. Load Config
      const config = await this.configService.loadConfig();
      if (!config) {
        console.log(pc.red('❌ Error: .skillsrc not found. Run `init` first.'));
        return;
      }

      // 2. Dynamic Update Configuration (Re-detection)
      const projectDeps = await this.detectionService.getProjectDeps();
      const skillsChanged = await this.syncService.reconcileConfig(
        config,
        projectDeps,
      );
      const workflowsChanged =
        await this.syncService.reconcileWorkflows(config);

      if (!options.dryRun && (skillsChanged || workflowsChanged)) {
        await this.configService.saveConfig(config);
      }

      // Resolve pins for workflows, specialists, and skills
      const resolvedRefs = await this.syncService.resolvePins(config);

      const pinEntries = Object.entries(resolvedRefs.newPins);
      if (pinEntries.length > 0) {
        const pinnedList = [
          resolvedRefs.newPins.workflows_ref,
          resolvedRefs.newPins.specialists_ref,
        ]
          .filter(Boolean)
          .join(', ');

        if (!options.dryRun) {
          if (resolvedRefs.newPins.workflows_ref) {
            config.workflows_ref = resolvedRefs.newPins.workflows_ref;
          }
          if (resolvedRefs.newPins.specialists_ref) {
            config.specialists_ref = resolvedRefs.newPins.specialists_ref;
          }
          await this.configService.saveConfig(config);
          console.log(pc.green(`📌 Pinned ${pinnedList} in .skillsrc`));
        } else {
          console.log(
            pc.gray(`  (dry-run) would pin ${pinnedList} in .skillsrc`),
          );
        }
      }

      for (const warning of resolvedRefs.warnings) {
        console.log(pc.yellow(warning));
      }

      // 3. Check for updates
      const updates = await this.syncService.checkForUpdates(config);

      if (updates && Object.keys(updates).length > 0) {
        if (options.dryRun) {
          if (!options.json) {
            for (const [cat, ref] of Object.entries(updates)) {
              console.log(pc.gray(`  (dry-run) would offer: ${cat} -> ${ref}`));
            }
          }
        } else {
          console.log(pc.yellow('\n🚀 New skill versions detected:'));
          for (const [cat, ref] of Object.entries(updates)) {
            const currentRef =
              cat === 'workflows'
                ? config.workflows_ref
                : cat === 'specialists'
                  ? config.specialists_ref
                  : config.skills[cat]?.ref;
            console.log(pc.gray(`  - ${cat}: ${currentRef} -> ${ref}`));
          }

          let update = options.yes;
          if (update === undefined) {
            if (!process.stdin.isTTY) {
              console.log(
                pc.cyan(
                  'ℹ️  Non-interactive environment detected. Skipping version updates. Use --yes to auto-confirm.',
                ),
              );
              update = false;
            } else {
              const answer = await inquirer.prompt([
                {
                  type: 'confirm',
                  name: 'update',
                  message:
                    'Do you want to update .skillsrc with these versions?',
                  default: true,
                },
              ]);
              update = answer.update;
            }
          }

          if (update) {
            for (const [cat, ref] of Object.entries(updates)) {
              if (cat === 'workflows') {
                config.workflows_ref = ref;
              } else if (cat === 'specialists') {
                config.specialists_ref = ref;
              } else if (config.skills[cat]) {
                config.skills[cat].ref = ref;
              }
            }
            await this.configService.saveConfig(config);
            console.log(pc.green('✅ .skillsrc updated.'));
          } else {
            console.log(
              pc.cyan('ℹ️  Skipping version updates, staying on pinned refs.'),
            );
          }
        }
      }

      if (!options.json) {
        console.log(pc.cyan(`🚀 Syncing skills from ${config.registry}...`));
      }

      // Begin ownership lifecycle
      await this.syncService.beginInstall(config, {
        dryRun: Boolean(options.dryRun),
        force: options.force ?? [],
      });

      // 4. Assemble skills from remote registry
      const enabledCategories = Object.keys(config.skills);
      const skills = await this.syncService.assembleSkills(
        enabledCategories,
        config,
      );

      // 4b. Assemble workflows
      const workflows = await this.syncService.assembleWorkflows(config);

      // 5. Write skills and workflows to target
      await this.syncService.writeSkills(skills, config);
      await this.syncService.writeWorkflows(workflows, config);

      // 5b. Sync specialists (sub-agents)
      const specialistsOk = await this.syncService.syncSpecialists(config);

      // Finalize ownership before refreshing indices so pruned members do not
      // remain in the generated category indexes or router.
      const plan = await this.syncService.completeInstall(config, {
        skills,
        workflows,
        specialistsOk,
        refreshIndices: true,
      });

      if (options.dryRun) {
        if (options.json) {
          console.log(
            JSON.stringify({
              schema_version: 1,
              kind: 'sync.plan',
              data: plan,
            }),
          );
        } else {
          console.log(pc.cyan('🔍 Dry run — no files written'));
          this.printPlanCounts(plan);
          if (options.verbose) {
            this.printVerbosePlan(plan);
          }
          console.log(
            pc.gray(
              '  (dry-run) skipped: MCP registration, hooks, capability notes',
            ),
          );
        }
        return;
      }

      this.printSummary(plan);
      await this.syncService.discloseCapabilities(config);
      console.log(pc.green('✅ All skills synced successfully!'));

      // 7. MCP integration (consent-respecting — see McpConfigService).
      await this.runMcpPhase(config, options);

      // 8. Hook installation — always runs; idempotent.
      await this.runHookPhase(config, options);
    } catch (error) {
      if (error instanceof Error) {
        console.error(pc.red('❌ Sync failed:'), error.message);
      } else {
        console.error(pc.red('❌ Sync failed:'), String(error));
      }
    }
  }

  /**
   * Phase 7 — MCP integration. Three paths:
   *   A. Never prompted yet: ask once now (with full value-prop), persist decision.
   *   B. Already prompted, mcp.enabled=true: dispatch install at the configured scope.
   *   C. Already prompted, mcp.enabled=false: skip silently.
   *
   * In non-interactive mode (no TTY) and never-prompted: skip with a hint, do
   * not assume consent. Users can opt in later via `ags mcp enable`.
   */
  private async runMcpPhase(
    config: SkillConfig,
    options: { yes?: boolean; snippets?: boolean },
  ): Promise<void> {
    const mcp = config.mcp ? { ...config.mcp } : defaultMcpConfig();
    const agents = config.agents ?? [];

    const snippetOnlyOverride =
      options.snippets === true && (!mcp.enabled || mcp.scope === 'disabled');
    if (snippetOnlyOverride) {
      mcp.enabled = true;
      mcp.scope = 'snippets-only';
      mcp.snippets = true;
    } else if (options.snippets !== undefined) {
      mcp.snippets = options.snippets;
    }

    if (
      !snippetOnlyOverride &&
      (!mcp.prompted || (!mcp.enabled && mcp.prompted))
    ) {
      if (!process.stdin.isTTY && !options.yes) {
        if (!mcp.prompted) {
          console.log(
            pc.gray(
              '\nℹ️  MCP integration not yet configured. Run `ags mcp enable` (or `ags mcp scope project`) when ready.',
            ),
          );
        }
        return;
      }

      // If already prompted but disabled, we ask again if they want to enable it now.
      // This ensures they aren't "stuck" in a disabled state just because they said no once.
      // Pass true for wasDisabled only if it was already prompted AND it is currently disabled.
      const decided = await this.promptMcpConsent(
        options,
        mcp.prompted && !mcp.enabled,
      );
      config.mcp = {
        enabled: decided.enabled,
        scope: decided.enabled ? decided.scope : 'disabled',
        prompted: true,
      };
      await this.configService.saveConfig(config);
    }

    const finalMcp = config.mcp ? { ...config.mcp } : defaultMcpConfig();
    if (snippetOnlyOverride) {
      finalMcp.enabled = true;
      finalMcp.scope = 'snippets-only';
      finalMcp.snippets = true;
    } else if (options.snippets !== undefined) {
      finalMcp.snippets = options.snippets;
    }

    if (!finalMcp.enabled || finalMcp.scope === 'disabled') {
      return;
    }

    const userScopePrompt = options.yes
      ? async () => true
      : async (agent: Agent, file: string): Promise<boolean> => {
          const { ok } = await inquirer.prompt([
            {
              type: 'confirm',
              name: 'ok',
              message: `Write user-scope MCP config for ${pc.cyan(agent)} at ${pc.gray(file)}?`,
              default: false,
            },
          ]);
          return ok;
        };

    console.log(pc.cyan('\n🔌 Wiring MCP server...'));
    const report = await this.mcpService.install({
      rootDir: process.cwd(),
      agents,
      mcp: finalMcp,
      userScopePrompt,
    });

    for (const w of report.projectWrites) {
      const tag =
        w.action === 'added'
          ? pc.green('  + added   ')
          : w.action === 'updated'
            ? pc.cyan('  ~ updated ')
            : pc.gray('  = up-to-date');
      console.log(`${tag} ${w.agent.padEnd(12)} ${pc.gray(w.file)}`);
    }
    for (const w of report.userWrites) {
      console.log(
        `  ${pc.green('+ wrote   ')} ${w.agent.padEnd(12)} ${pc.gray(w.file)}`,
      );
    }
    for (const d of report.declined) {
      console.log(
        `  ${pc.gray('-         ')} ${d.agent.padEnd(12)} ${pc.gray(d.file)} (declined)`,
      );
    }
    if (report.snippets.length > 0) {
      console.log(
        pc.gray(
          `  ${report.snippets.length} snippet(s) written to ./mcp-config-snippets/`,
        ),
      );
    }
    if (report.unsupported.length > 0) {
      console.log(
        pc.gray(
          `  (skipped — no MCP support yet: ${report.unsupported.join(', ')})`,
        ),
      );
    }
  }

  private async promptMcpConsent(
    options: {
      yes?: boolean;
    },
    wasDisabled = false,
  ): Promise<{ enabled: boolean; scope: McpScope }> {
    if (options.yes) {
      // Conservative default for --yes: opt in at project scope (the recommended choice).
      return { enabled: true, scope: 'project' };
    }
    console.log(pc.bold('\n🔌 MCP server setup\n'));
    if (wasDisabled) {
      console.log(
        pc.yellow(
          'MCP integration is currently disabled. Would you like to enable it now?',
        ),
      );
    }
    console.log(
      'agent-skills-standard ships an optional MCP server that serves your skills',
    );
    console.log('to AI agents at runtime. Quick comparison:\n');
    console.log(
      pc.bold('  WITHOUT MCP:') +
        ' sub-agents skip skill loading; no audit trail',
    );
    console.log(
      pc.bold('  WITH MCP:   ') +
        ' every sub-agent can call load_skills_for_files; auditable\n',
    );

    const decision = await inquirer.prompt<{
      enabled: boolean;
      scope: McpScope;
    }>([
      {
        type: 'confirm',
        name: 'enabled',
        message: 'Enable MCP server integration?',
        default: true,
      },
      {
        type: 'rawlist',
        name: 'scope',
        message: 'Where should sync write MCP configs?',
        when: (a) => a.enabled === true,
        choices: [
          {
            name: 'project (recommended)  — only files inside this project',
            value: 'project',
          },
          {
            name: 'user                    — also $HOME files (sync prompts each)',
            value: 'user',
          },
          {
            name: 'snippets-only           — never edits any runtime config',
            value: 'snippets-only',
          },
        ],
        default: 'project',
      },
    ]);
    return decision;
  }

  /**
   * Phase 8 — Hook installation.
   * Idempotent: registers the Claude PreToolUse entry and keeps managed hook
   * files up to date. Claude's script is preserved if already customized; Kiro's
   * markdown hook is kept in sync with the embedded template.
   */
  private async runHookPhase(
    config: SkillConfig,
    options: { yes?: boolean } = {},
  ): Promise<void> {
    const agents = config.agents ?? [];
    if (agents.length === 0) return;

    const mcp = config.mcp ?? defaultMcpConfig();
    if (!mcp.enabled || mcp.scope === 'disabled') {
      await this.hookService.uninstall({ rootDir: process.cwd(), agents });
      return;
    }

    const promptPermission = options.yes
      ? async () => true
      : async (agent: Agent): Promise<boolean> => {
          if (!process.stdin.isTTY) {
            console.log(
              pc.gray(
                `\nℹ️  Skipping MCP permission grant for ${agent} (non-interactive; use --yes to auto-confirm).`,
              ),
            );
            return false;
          }
          const { ok } = await inquirer.prompt([
            {
              type: 'confirm',
              name: 'ok',
              message: `Allow ${pc.cyan(agent)} to auto-run the agent-skills-standard MCP tools (adds "${CLAUDE_MCP_PERMISSION}" to permissions.allow)?`,
              default: true,
            },
          ]);
          return ok;
        };

    const report = await this.hookService.install({
      rootDir: process.cwd(),
      agents,
      promptPermission,
    });

    const writes = report.writes.filter((w) => w.action !== 'skipped-existing');
    if (writes.length === 0) return;

    console.log(pc.cyan('\n🪝 Updating skill-loader hooks...'));
    for (const w of writes) {
      const tag =
        w.action === 'added' ? pc.green('+ added   ') : pc.cyan('~ updated ');
      console.log(`  ${tag} ${w.agent.padEnd(12)} ${pc.gray(w.file)}`);
    }
  }

  private printPlanCounts(plan: InstallPlan): void {
    console.log(
      `📦 Install: ${plan.added.length} added, ${plan.updated.length} updated, ${plan.unchanged.length} unchanged, ${plan.kept.length} kept (your edits), ${plan.pruned.length} pruned`,
    );
  }

  private printSummary(plan: InstallPlan): void {
    this.printPlanCounts(plan);

    const allKept = [...plan.kept, ...plan.keptOrphans];
    if (allKept.length > 0) {
      const preview = allKept.slice(0, 3).join(', ');
      const more = allKept.length > 3 ? `, +${allKept.length - 3} more` : '';
      console.log(
        pc.yellow(
          `   Kept your edits: ${preview}${more} — overwrite with ags sync --force <path>`,
        ),
      );
    }

    if (plan.unknown.length > 0) {
      const preview = plan.unknown.slice(0, 3).join(', ');
      const more =
        plan.unknown.length > 3 ? `, +${plan.unknown.length - 3} more` : '';
      console.log(
        pc.gray(
          `   Left ${plan.unknown.length} existing file(s) ags does not own: ${preview}${more}`,
        ),
      );
    }

    if (plan.backupId) {
      console.log(
        pc.gray(
          `   Backup: .ags/backups/${plan.backupId} (undo with ags restore ${plan.backupId})`,
        ),
      );
    }
  }

  private printVerbosePlan(plan: InstallPlan): void {
    for (const p of plan.added) console.log(pc.green(`  + ${p}`));
    for (const p of plan.updated) console.log(pc.cyan(`  ~ ${p}`));
    for (const p of plan.kept) console.log(pc.yellow(`  = ${p}`));
    for (const p of plan.unknown) console.log(pc.gray(`  ? ${p}`));
    for (const p of plan.pruned) console.log(pc.red(`  - ${p}`));
    for (const p of plan.keptOrphans) console.log(pc.yellow(`  ! ${p}`));
  }
}
