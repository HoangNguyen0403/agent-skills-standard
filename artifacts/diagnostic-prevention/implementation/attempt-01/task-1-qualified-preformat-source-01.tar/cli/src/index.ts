#!/usr/bin/env node
import { Command } from 'commander';
import dotenv from 'dotenv';
import pc from 'picocolors';
import pkg from '../package.json';
import { EvalsCommand } from './commands/evals';
import { DoctorCommand } from './commands/doctor';
import { FeedbackCommand } from './commands/feedback';
import { HooksCommand } from './commands/hooks';
import { InitCommand } from './commands/init';
import { ListSkillsCommand } from './commands/list-skills';
import { McpCommand } from './commands/mcp';
import { SyncCommand } from './commands/sync';
import { AuditCommand } from './commands/audit';
import { UpgradeCommand } from './commands/upgrade';
import { ValidateCommand } from './commands/validate-skills';
import { VerifyCommand } from './commands/verify';
import { RestoreCommand } from './commands/restore';
import { UninstallCommand } from './commands/uninstall';
import { PolicyCommand } from './commands/policy';

// Load .env from current directory (for development and other env vars)
dotenv.config();

// Detect stale pnpm shim: old pnpm global stores don't embed the version tag
// in the shim path (e.g. /global/v11/<hash>/node_modules/...).  When such a
// shim is executed, `ags -V` always reports an old version even though the
// package store was updated.  Surface the issue immediately on every invocation
// so users are not silently misled.
const _agsExecPath = process.argv[1] ?? '';
if (
  _agsExecPath.includes('/pnpm/') &&
  _agsExecPath.includes('/node_modules/agent-skills-standard/') &&
  !_agsExecPath.includes(`agent-skills-standard@${pkg.version}`)
) {
  process.stderr.write(
    `\n${pc.yellow('⚠️  ags is running from a stale global shim — reported version will be wrong.')}\n` +
      `   ${pc.cyan('Quickfix:')} ${pc.bold('npx agent-skills-standard@latest upgrade')} ` +
      pc.gray('(auto-detects & removes the stale shim)') +
      '\n\n',
  );
}

const program = new Command();

program
  .name('agent-skills-standard')
  .description(
    'A CLI to manage and sync AI agent skills for Cursor, Claude, Copilot, Windsurf, and more.',
  )
  .version(pkg.version);

program
  .command('init')
  .description('Initialize a .skillsrc configuration file interactively')
  .action(async () => {
    const init = new InitCommand();
    await init.run();
  });

program
  .command('sync')
  .description('Sync skills to AI Agent skill directories')
  .option(
    '-y, --yes',
    'Automatically confirm interactive prompts (e.g. update versions)',
  )
  .option(
    '--snippets',
    'Generate JSON config snippets in ./mcp-config-snippets/; if MCP is disabled, run snippet-only mode',
  )
  .option('--dry-run', 'Show what sync would change without writing anything')
  .option(
    '--force <paths...>',
    'Overwrite these files even if you edited them (backed up first)',
  )
  .option('--verbose', 'With --dry-run: list every path')
  .option('--json', 'With --dry-run: print the plan as JSON (sync.plan)')
  .action(async (options) => {
    const sync = new SyncCommand();
    await sync.run(options);
  });

program
  .command('verify')
  .description(
    'Check installed files against .skills-lock.json (catches tampering, partial writes, or manual drift)',
  )
  .option(
    '--agent <agent>',
    'Which agent skill directory to verify (default: first configured agent)',
  )
  .option(
    '--strict',
    'Fail if any locked ref has moved (resolves to a different commit)',
  )
  .option(
    '--attestation',
    'Verify build-provenance attestations using the GitHub CLI (gh)',
  )
  .action(async (options) => {
    const cmd = new VerifyCommand();
    await cmd.run(options);
  });

program
  .command('audit')
  .description('Print the installed inventory recorded in .skills-lock.json')
  .action(async () => {
    const cmd = new AuditCommand();
    await cmd.run();
  });

program
  .command('restore [id]')
  .description('List backups in .ags/backups or restore one (replace-only)')
  .option('--list', 'List available backups')
  .action(async (id: string | undefined, options: { list?: boolean }) => {
    await new RestoreCommand().run(id, options);
  });

program
  .command('uninstall')
  .description(
    'Remove files ags installed (keeps files you edited); backs up first',
  )
  .option(
    '--all',
    'Remove everything ags installed, plus MCP entries, hook registrations, and the AGENTS.md index block',
  )
  .option(
    '--agent <agents...>',
    'Remove only what was installed for these agents',
  )
  .option('--category <categories...>', 'Remove only these skill categories')
  .option('--dry-run', 'Show what would be removed')
  .option('-y, --yes', 'Apply without prompting')
  .action(async (options) => {
    await new UninstallCommand().run(options);
  });

program
  .command('list-skills')
  .description('List available framework skills and detection status')
  .option('-f, --framework <framework>', 'The framework to list skills for')
  .action(async (options) => {
    const cmd = new ListSkillsCommand();
    await cmd.run(options);
  });

program
  .command('validate')
  .description('Validate skill format and token efficiency standards')
  .option('--all', 'Validate all skills instead of only changed ones')
  .action(async (options) => {
    const cmd = new ValidateCommand();
    await cmd.run(options);
  });

program
  .command('feedback')
  .description('Report skill improvement opportunities or AI agent mistakes')
  .option(
    '--skill <skill>',
    'The skill ID (e.g., flutter/bloc-state-management)',
  )
  .option('--issue <issue>', 'Brief description of the issue')
  .option('--model <model>', 'AI agent model (e.g., Claude 3.5 Sonnet)')
  .option('--context <context>', 'Additional context (e.g., framework version)')
  .option('--suggestion <suggestion>', 'Suggested improvement')
  .option(
    '--skill-instruction <instruction>',
    'Exact quote from skill that was violated (AI auto-report)',
  )
  .option(
    '--actual-action <action>',
    'What you actually did instead of following skill (AI auto-report)',
  )
  .option(
    '--decision-reason <reason>',
    'Why you chose this approach instead (AI auto-report)',
  )
  .option(
    '--loaded-skills <skills>',
    'Comma-separated list of currently loaded skills (platform-provided)',
  )
  .option(
    '--root-cause <cause>',
    'Why the violation happened: AMBIGUOUS_RULE | MISSING_COVERAGE | OUTDATED_GUIDANCE | COMPETING_RULES | PATTERN_MISMATCH',
  )
  .option('--user-intent <intent>', 'What the user was trying to achieve')
  .option(
    '--skill-gap <gap>',
    'What change to the SKILL.md would prevent this violation next time',
  )
  .action(async (options: Record<string, string>) => {
    const cmd = new FeedbackCommand();
    await cmd.run(options);
  });

program
  .command('upgrade')
  .description('Upgrade the CLI to the latest version')
  .option('--dry-run', 'Check for updates without installing')
  .action(async (options) => {
    const cmd = new UpgradeCommand();
    await cmd.run(options);
  });

program
  .command('mcp <action> [scope]')
  .description(
    'Manage the optional MCP server integration. Actions: status | enable | disable | scope <project|user|snippets-only|disabled> | install | uninstall | snippets',
  )
  .option(
    '--scope <scope>',
    'Override scope for install (project|user|snippets-only|disabled)',
  )
  .option(
    '--from <from>',
    'For uninstall: project | user | all (default: project)',
  )
  .action(
    async (
      action: string,
      positional: string | undefined,
      opts: Record<string, string>,
    ) => {
      // Allow `ags mcp scope project` (positional) AND `ags mcp scope --scope project`.
      const merged: Record<string, string> = { ...opts };
      if (positional) merged.scope = opts.scope ?? positional;
      const cmd = new McpCommand();
      await cmd.run(action, merged);
    },
  );

program
  .command('hooks <action>')
  .description(
    'Manage the PreToolUse skill-loader hook. Actions: status | install | uninstall',
  )
  .option(
    '--enforce',
    'With "install": Claude blocks (does not just remind) edits to SOUL.md, MEMORY.md, .env*, .ssh/, credentials*.json|yaml',
  )
  .action(async (action: string, options: { enforce?: boolean }) => {
    const cmd = new HooksCommand();
    await cmd.run(action, options);
  });

program
  .command('doctor')
  .description(
    'Check installation health (config, agents, lock file, MCP, hooks, CLI version)',
  )
  .option('--json', 'Emit a versioned JSON report (doctor.report)')
  .option('--exit-on-fail', 'Exit 1 when any check fails')
  .option('--fix', 'Apply available safe fixes (asks per fix unless --yes)')
  .option('-y, --yes', 'Apply fixes without prompting')
  .option('--offline', 'Skip the network-backed cli_version check')
  .action(async (options) => {
    const cmd = new DoctorCommand();
    await cmd.run(options);
  });

program
  .command('evals <action>')
  .description(
    'Verify or display live skill-eval runs. Actions: verify | report',
  )
  .option(
    '--run <runId>',
    'For verify: check a single run id instead of all committed runs',
  )
  .action(async (action: string, opts: { run?: string }) => {
    const cmd = new EvalsCommand();
    await cmd.run(action, opts);
  });

const policyCmd = program
  .command('policy')
  .description(
    'Manage and check project agent policies. Prevents mistakes by cooperating agents; not a security boundary.',
  );

policyCmd
  .command('status')
  .description('Show policy rules in force and built-in rules')
  .option('--json', 'Output status as JSON')
  .action(async (options) => {
    await new PolicyCommand().status(options);
  });

policyCmd
  .command('check')
  .description(
    'Evaluate a file path, command, or git diff against policy rules',
  )
  .option('--path <path>', 'Relative path to check')
  .option('--command <command>', 'Executable to check')
  .option('--diff', 'Check required checks against git diff')
  .option('--no-bypass', 'Ignore AGS_POLICY_BYPASS environment variable')
  .option('--json', 'Output decision as JSON')
  .action(async (options) => {
    await new PolicyCommand().check(options);
  });

policyCmd
  .command('validate')
  .description('Validate policy file for conflicts and stale compiled rules')
  .option('--fail-on-stale', 'Fail if any compiled rules are stale')
  .option('--json', 'Output validation result as JSON')
  .action(async (options) => {
    await new PolicyCommand().validate(options);
  });

policyCmd
  .command('compile')
  .description('Compile proposed policy rules from AGENTS.md and CLAUDE.md')
  .option('--json', 'Output candidates as JSON')
  .action(async (options) => {
    await new PolicyCommand().compile(options);
  });

policyCmd
  .command('adopt <ids...>')
  .description('Adopt candidate rules into .ags/policy.json')
  .option('--json', 'Output adoption result as JSON')
  .action(async (ids: string[], options) => {
    await new PolicyCommand().adopt(ids, options);
  });

program.parse();
