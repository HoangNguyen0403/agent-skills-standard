import fs from 'fs-extra';
import type { Stats } from 'node:fs';
import path from 'path';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { Agent, DEFAULT_WORKFLOWS } from '../../constants';
import { SkillConfig } from '../../models/config';
import { WorkflowSyncService } from '../WorkflowSyncService';
import type { ManifestVerifier } from '../install/ManifestVerifier';

// Mock fs-extra
vi.mock('fs-extra');

describe('WorkflowSyncService', () => {
  let workflowSyncService: WorkflowSyncService;
  let mockGithubService: Record<string, any>;

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(fs.lstat as (path: string) => Promise<Stats>).mockResolvedValue({
      isSymbolicLink: () => false,
    } as Stats);

    mockGithubService = {
      getRepoTree: vi.fn(),
      fetchSkillFiles: vi.fn(),
      downloadFilesConcurrent: vi.fn(),
      getRawFile: vi.fn(),
      getRepoInfo: vi.fn(),
    };

    workflowSyncService = new WorkflowSyncService(mockGithubService as any);

    vi.spyOn(console, 'log').mockImplementation(() => {});
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  describe('reconcileWorkflows', () => {
    it('should include agentic SDLC learning workflows in defaults', () => {
      expect(DEFAULT_WORKFLOWS).toEqual(
        expect.arrayContaining([
          'implementation-readiness',
          'review-ticket',
          'traceability-audit',
          'session-report',
        ]),
      );
    });

    it('should return false if treeData is missing', async () => {
      mockGithubService.getRepoTree.mockResolvedValue(null);
      const result = await workflowSyncService.reconcileWorkflows({
        registry: 'https://github.com/o/r',
      } as any);
      expect(result).toBe(false);
    });

    it('should return false if no workflows are in repo', async () => {
      mockGithubService.getRepoTree.mockResolvedValue({ tree: [] });
      const result = await workflowSyncService.reconcileWorkflows({
        registry: 'https://github.com/o/r',
      } as any);
      expect(result).toBe(false);
    });

    it('should discover and add new workflows from DEFAULT_WORKFLOWS if config.workflows is an array', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: ['code-review'],
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/code-review.md' },
          { path: '.agents/workflows/plan-feature.md' },
          { path: '.agents/workflows/custom.md' },
        ],
      });

      const result = await workflowSyncService.reconcileWorkflows(config);

      expect(result).toBe(true);
      expect(config.workflows).toContain('code-review');
      expect(config.workflows).toContain('plan-feature');
      expect(config.workflows).not.toContain('custom');
    });

    it('should return false if all default workflows are already present', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: [
          'code-review',
          'plan-feature',
          'smart-release',
          'update-docs',
          'skill-benchmark',
          'battle-test',
          'create-skillset',
          'codebase-review',
        ],
      } as any;
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/code-review.md' }],
      });
      const result = await workflowSyncService.reconcileWorkflows(config);
      expect(result).toBe(false);
    });

    it('should initialize workflows to default array if undefined', async () => {
      const config = {
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/code-review.md' }],
      });

      const result = await workflowSyncService.reconcileWorkflows(config);

      expect(result).toBe(true);
      expect(Array.isArray(config.workflows)).toBe(true);
      expect(config.workflows).toContain('code-review');
    });

    it('should preserve workflows: true as a stable state', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: true,
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/code-review.md' }],
      });

      const result = await workflowSyncService.reconcileWorkflows(config);

      expect(result).toBe(false); // No change to .skillsrc
      expect(config.workflows).toBe(true);
    });

    it('should never auto-discover or add the internal-only evals-run workflow', async () => {
      const config = {
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/code-review.md' },
          { path: '.agents/workflows/evals-run.md' },
        ],
      });

      await workflowSyncService.reconcileWorkflows(config);

      expect(config.workflows).toContain('code-review');
      expect(config.workflows).not.toContain('evals-run');
    });

    it('should fetch tree at the passed ref and not call getRepoInfo', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: true,
      } as unknown as SkillConfig;
      mockGithubService.getRepoTree.mockResolvedValue({ tree: [] });

      await workflowSyncService.reconcileWorkflows(config, 'workflows-v1.0.0');

      expect(mockGithubService.getRepoTree).toHaveBeenCalledWith(
        'o',
        'r',
        'workflows-v1.0.0',
      );
      expect(mockGithubService.getRepoInfo).not.toHaveBeenCalled();
    });
  });

  describe('assembleWorkflows', () => {
    it('should return empty if workflows are disabled in config', async () => {
      const config = { workflows: false } as unknown as SkillConfig;
      const result = await workflowSyncService.assembleWorkflows(config);
      expect(result).toEqual([]);
    });

    it('should return empty if registry URL is invalid', async () => {
      const config = { workflows: true, registry: 'invalid' } as any;
      const result = await workflowSyncService.assembleWorkflows(config);
      expect(result).toEqual([]);
    });

    it('should return empty if repo tree fails to fetch', async () => {
      const config = {
        workflows: true,
        registry: 'https://github.com/o/r',
      } as any;
      mockGithubService.getRepoTree.mockResolvedValue(null);
      const result = await workflowSyncService.assembleWorkflows(config);
      expect(result).toEqual([]);
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('Failed to fetch workflows'),
      );
    });

    it('should fetch all workflows if config.workflows is true', async () => {
      const config = {
        workflows: true,
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      const treeData = {
        tree: [{ path: '.agents/workflows/w1.md' }, { path: 'other/file.md' }],
      };
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'develop',
      });
      mockGithubService.getRepoTree.mockResolvedValue(treeData);
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [{ path: '.agents/workflows/w1.md', content: 'c1' }],
        failed: [],
      });

      const result = await workflowSyncService.assembleWorkflows(config);

      expect(result).toHaveLength(1);
      expect(result[0].skill).toBe('workflows');
    });

    it('should never sync internal-only workflows (evals-run) even when workflows is true', async () => {
      const config = {
        workflows: true,
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/w1.md' },
          { path: '.agents/workflows/evals-run.md' },
        ],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [{ path: '.agents/workflows/w1.md', content: 'c1' }],
        failed: [],
      });

      await workflowSyncService.assembleWorkflows(config);

      expect(mockGithubService.downloadFilesConcurrent).toHaveBeenCalledWith([
        expect.objectContaining({ path: '.agents/workflows/w1.md' }),
      ]);
    });

    it('should never sync internal-only workflows (evals-run) even when explicitly listed', async () => {
      const config = {
        workflows: ['w1', 'evals-run'],
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/w1.md' },
          { path: '.agents/workflows/evals-run.md' },
        ],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [{ path: '.agents/workflows/w1.md', content: 'c1' }],
        failed: [],
      });

      await workflowSyncService.assembleWorkflows(config);

      expect(mockGithubService.downloadFilesConcurrent).toHaveBeenCalledWith([
        expect.objectContaining({ path: '.agents/workflows/w1.md' }),
      ]);
    });

    it('should only discover workflows from .agents/workflows source path', async () => {
      const config = {
        workflows: true,
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/w1.md' },
          { path: '.agents/workflows/references/runtime-contract.md' },
          { path: 'workflows/w2.md' },
          { path: '.codex/skills/w3/SKILL.md' },
        ],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [{ path: '.agents/workflows/w1.md', content: 'c1' }],
        failed: [],
      });

      const result = await workflowSyncService.assembleWorkflows(config);

      expect(result).toHaveLength(1);
      expect(result[0].files).toHaveLength(1);
      expect(result[0].files[0].name).toBe('w1.md');
    });

    it('should fetch specific workflows if config.workflows is an array', async () => {
      const config = {
        workflows: ['w1'],
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      const treeData = {
        tree: [
          { path: '.agents/workflows/w1.md' },
          { path: '.agents/workflows/w2.md' },
        ],
      };
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue(treeData);
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [],
        failed: [],
      });

      const result = await workflowSyncService.assembleWorkflows(config);
      expect(result).toEqual([]);
    });

    it('should fetch tree at the passed ref and not call getRepoInfo', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: true,
      } as unknown as SkillConfig;
      mockGithubService.getRepoTree.mockResolvedValue({ tree: [] });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [],
        failed: [],
      });

      await workflowSyncService.assembleWorkflows(config, 'workflows-v1.0.0');

      expect(mockGithubService.getRepoTree).toHaveBeenCalledWith(
        'o',
        'r',
        'workflows-v1.0.0',
      );
      expect(mockGithubService.getRepoInfo).not.toHaveBeenCalled();
    });

    it('should drop rejected workflow files and keep valid ones when verifier rejects a file', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: true,
      } as unknown as SkillConfig;
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/valid.md', type: 'blob' },
          { path: '.agents/workflows/tampered.md', type: 'blob' },
        ],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [
          { path: '.agents/workflows/valid.md', content: 'good' },
          { path: '.agents/workflows/tampered.md', content: 'bad' },
        ],
        failed: [],
      });

      const fakeVerifier = {
        check: vi.fn().mockImplementation((path: string) => {
          if (path.includes('tampered.md')) {
            return 'sha256 does not match release MANIFEST.json';
          }
          return null;
        }),
      };

      const result = await workflowSyncService.assembleWorkflows(
        config,
        'workflows-v1.0.0',
        fakeVerifier as unknown as ManifestVerifier,
      );

      expect(result).toHaveLength(1);
      expect(result[0].files).toHaveLength(1);
      expect(result[0].files[0].name).toBe('valid.md');
    });
  });

  describe('writeWorkflows', () => {
    it('should bail if no workflows to write', async () => {
      await workflowSyncService.writeWorkflows([], {} as any);
      expect(fs.ensureDir).not.toHaveBeenCalled();
    });

    it('should write native workflow files for Antigravity', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            { name: 'test.md', content: '---\ndescription: test\n---\n# Test' },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Antigravity,
      ]);
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining('test.md'),
        expect.any(String),
      );
    });
    it('routes whole-file writes through injected InstallWriter with expected meta', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            { name: 'test.md', content: '---\ndescription: test\n---\n# Test' },
          ],
        },
      ];
      const fakeWriter = { write: vi.fn() };
      await workflowSyncService.writeWorkflows(
        workflows as unknown as CollectedSkill[],
        {} as unknown as SkillConfig,
        [Agent.Antigravity],
        fakeWriter as unknown as InstallWriter,
      );
      expect(fakeWriter.write).toHaveBeenCalledWith(
        expect.stringContaining('test.md'),
        expect.any(String),
        {
          owner: 'workflow',
          source: 'workflow:test',
          agent: 'antigravity',
        },
      );
    });

    it('should transform to Claude command format with $ARGUMENTS', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content:
                '---\ndescription: Review code.\n---\n# Review\n## Step 1',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Claude,
      ]);
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining('review.md'),
        expect.stringContaining('$ARGUMENTS'),
      );
    });

    it('should transform to Gemini toml command format', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content: '---\ndescription: Review.\n---\n# Review',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Gemini,
      ]);
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining('review.toml'),
        expect.stringContaining('{{args}}'),
      );
    });

    it('should transform to Copilot prompt format', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content: '---\ndescription: Review.\n---\n# Review',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Copilot,
      ]);
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining('review.prompt.md'),
        expect.stringContaining('description: "Review."'),
      );
    });

    it('should transform to Codex skill format in .codex/skills/<workflow>/SKILL.md', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content:
                '---\ndescription: Review with sub-agent fallback.\n---\n# Review\nDelegate if supported, otherwise run locally.',
            },
          ],
        },
      ];

      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Codex,
      ]);

      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining(
          path.join('.codex', 'skills', 'review', 'SKILL.md'),
        ),
        expect.stringContaining('## Instructions'),
      );
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining(
          path.join('.codex', 'skills', 'review', 'SKILL.md'),
        ),
        expect.stringContaining(
          'Delegate if supported, otherwise run locally.',
        ),
      );
    });

    it('should write native workflows for Windsurf (.windsurf/workflows)', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content: '---\ndescription: Review.\n---\n# Review',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Windsurf,
      ]);
      expect(fs.outputFile).toHaveBeenCalledWith(
        expect.stringContaining(path.join('.windsurf', 'workflows')),
        expect.stringContaining('# Review'),
      );
    });

    it('should write to multiple agents with different formats', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: 'review.md',
              content: '---\ndescription: Review.\n---\n# Review',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Antigravity,
        Agent.Claude,
        Agent.Gemini,
      ]);
      expect(fs.outputFile).toHaveBeenCalledTimes(3);
    });

    it('should skip workflows where skill is not "workflows"', async () => {
      const workflows = [{ skill: 'not-workflows', files: [] }];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Antigravity,
      ]);
      expect(fs.outputFile).not.toHaveBeenCalled();
    });

    it('should handle security error for dangerous paths', async () => {
      const workflows = [
        {
          skill: 'workflows',
          files: [
            {
              name: '../malicious.md',
              content: '---\ndescription: evil\n---\n# Evil',
            },
          ],
        },
      ];
      await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
        Agent.Antigravity,
      ]);
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('Security Error'),
      );
      expect(fs.outputFile).not.toHaveBeenCalled();
    });

    describe('writeWorkflows additional coverage', () => {
      it('should handle native skill folder format (agent.workflowFormat === "skill")', async () => {
        const workflows = [
          {
            skill: 'workflows',
            files: [
              {
                name: 'test.md',
                content: '---\ndescription: test\n---\n# Test',
              },
            ],
          },
        ];

        await workflowSyncService.writeWorkflows(workflows as any, {} as any, [
          Agent.Cursor,
        ]);
        // Should be path/workflowName/SKILL.md
        expect(fs.outputFile).toHaveBeenCalledWith(
          expect.stringContaining(
            path.join('.cursor', 'skills', 'test', 'SKILL.md'),
          ),
          expect.any(String),
        );
      });

      it('should handle overrides', async () => {
        const workflows = [
          {
            skill: 'workflows',
            files: [
              {
                name: 'overridden.md',
                content: '---\ndescription: test\n---\n# Test',
              },
            ],
          },
        ];
        // Antigravity workflow path is .agents/workflows
        const targetPath = path.join(
          process.cwd(),
          '.agents/workflows/overridden.md',
        );
        const relPath = path
          .relative(process.cwd(), targetPath)
          .replace(/\\/g, '/');
        const overrides = [relPath];

        await workflowSyncService.writeWorkflows(
          workflows as any,
          { custom_overrides: overrides } as any,
          [Agent.Antigravity],
        );

        expect(fs.outputFile).not.toHaveBeenCalled();
      });

      it('should handle partial path overrides', async () => {
        const workflows = [
          {
            skill: 'workflows',
            files: [
              {
                name: 'sub/test.md',
                content: '---\ndescription: test\n---\n# Test',
              },
            ],
          },
        ];
        // Antigravity workflow path is .agents/workflows
        const targetPath = path.join(
          process.cwd(),
          '.agents/workflows/sub/test.md',
        );
        const relPath = path
          .relative(
            process.cwd(),
            path.join(process.cwd(), '.agents/workflows/sub'),
          )
          .replace(/\\/g, '/');
        const overrides = [relPath];

        await workflowSyncService.writeWorkflows(
          workflows as any,
          { custom_overrides: overrides } as any,
          [Agent.Antigravity],
        );
        expect(fs.outputFile).not.toHaveBeenCalled();
      });
    });
  });

  describe('reconcileWorkflows additional branches (Line 78)', () => {
    it('should log when config.workflows is true and there are non-default workflows available', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: true,
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/custom.md' }],
      });

      const logSpy = vi.spyOn(console, 'log');
      const result = await workflowSyncService.reconcileWorkflows(config);

      expect(result).toBe(false);
      expect(logSpy).toHaveBeenCalledWith(
        expect.stringContaining(
          'Registry has 1 workflows (including 1 non-default)',
        ),
      );
    });
  });

  describe('assembleWorkflows edge cases (Lines 119, 146)', () => {
    it('should return false inside filter loop when config.workflows is unsupported type', async () => {
      const config = {
        workflows: 12345,
        registry: 'https://github.com/o/r',
      } as any;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/w1.md' }],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [],
        failed: [],
      });

      const result = await workflowSyncService.assembleWorkflows(config);
      expect(result).toEqual([]);
      expect(mockGithubService.downloadFilesConcurrent).toHaveBeenCalledWith(
        [],
      );
    });

    it('should print log when no matching workflows found in registry', async () => {
      const config = {
        workflows: ['non-existent'],
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [{ path: '.agents/workflows/w1.md' }],
      });
      mockGithubService.downloadFilesConcurrent.mockResolvedValue({
        ok: [],
        failed: [],
      });

      const logSpy = vi.spyOn(console, 'log');
      const result = await workflowSyncService.assembleWorkflows(config);

      expect(result).toEqual([]);
      expect(logSpy).toHaveBeenCalledWith(
        expect.stringContaining('No matching workflows found in registry'),
      );
    });
  });

  describe('optional product evidence workflows sync semantics', () => {
    const OPTIONAL_PM_WORKFLOWS = [
      'discover-product',
      'validate-product',
      'review-product-value',
    ];

    it('does not include optional PM workflows in DEFAULT_WORKFLOWS spine', () => {
      for (const wf of OPTIONAL_PM_WORKFLOWS) {
        expect(DEFAULT_WORKFLOWS).not.toContain(wf);
      }
    });

    it('initializes omitted workflows with available defaults and excludes optional PM workflows', async () => {
      const config = {
        registry: 'https://github.com/o/r',
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/code-review.md' },
          { path: '.agents/workflows/discover-product.md' },
          { path: '.agents/workflows/validate-product.md' },
        ],
      });

      await workflowSyncService.reconcileWorkflows(config);

      expect(config.workflows).toEqual(['code-review']);
    });

    it('preserves explicitly selected optional workflow and reconciles defaults without unselected optionals', async () => {
      const config = {
        registry: 'https://github.com/o/r',
        workflows: ['discover-product'],
      } as unknown as SkillConfig;
      mockGithubService.getRepoInfo.mockResolvedValue({
        default_branch: 'main',
      });
      mockGithubService.getRepoTree.mockResolvedValue({
        tree: [
          { path: '.agents/workflows/code-review.md' },
          { path: '.agents/workflows/discover-product.md' },
          { path: '.agents/workflows/validate-product.md' },
          { path: '.agents/workflows/review-product-value.md' },
        ],
      });

      const changed = await workflowSyncService.reconcileWorkflows(config);

      expect(changed).toBe(true);
      expect(config.workflows).toContain('discover-product');
      expect(config.workflows).toContain('code-review');
      expect(config.workflows).not.toContain('validate-product');
      expect(config.workflows).not.toContain('review-product-value');
    });
  });
});
