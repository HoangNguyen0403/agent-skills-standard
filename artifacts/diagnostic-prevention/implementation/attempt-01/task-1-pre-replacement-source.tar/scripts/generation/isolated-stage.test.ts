import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs-extra';
import path from 'path';
import os from 'os';
import { spawn } from 'child_process';
import {
  buildGenerationPlan,
  copySourceToStage,
  linkDependencies,
  parseCategoryIndexRows,
  runInStage,
  runIsolatedGeneration,
} from './isolated-stage';
import { sha256 } from '../../cli/src/services/LockfileService';
import { Agent } from '../../cli/src/constants';
import type { SkillConfig } from '../../cli/src/models/config';
import type { CollectedSkill } from '../../cli/src/models/types';
import { SyncService } from '../../cli/src/services/SyncService';

const REPOSITORY_ROOT = path.resolve(__dirname, '..', '..');
interface FixtureOptions {
  /** Install a generate-indices wrapper that mutates after the real producer. */
  mutateDuringIndices?: boolean;
  /** Mutate a canonical input from the staged child during generation. */
  driftSourceDuringIndices?: boolean;
  /** Fail the real child phase after its producer completes. */
  failAfterIndices?: boolean;
  /** Remove the baseline capabilities doc (docs/ directory stays). */
  omitBaselineCapabilitiesDoc?: boolean;
  /** Skip all baseline mirror files for this skill. */
  omitMirrorSkill?: string;
  inheritedRootResource?: string;
  includeMetricsReadme?: boolean;
}

const SKILL_ALPHA =
  '---\nname: common-alpha\ndescription: "Alpha skill (triggers: *.alpha)"\nmetadata:\n  triggers:\n    files:\n      - "*.alpha"\n---\n# Alpha\n';
const SKILL_BETA =
  '---\nname: common-beta\ndescription: "Beta skill (triggers: *.beta)"\nmetadata:\n  triggers:\n    keywords:\n      - beta\n---\n# Beta\n';
const SPECIALIST_ARCH =
  '---\nname: specialist-arch\ndescription: Architecture specialist\nallowed-tools: [read]\n---\nSpecialist body\n';
const LICENSE_TEXT = 'Fixture License\n\nAll rights reserved.\n';

const GENERATE_INDICES_WRAPPER = [
  "const { spawnSync } = require('child_process');",
  "const path = require('path');",
  "const fs = require('fs');",
  "const impl = path.join(__dirname, 'generate-indices.impl.ts');",
  'const result = spawnSync(process.execPath, [',
  "  '--import',",
  "  'tsx',",
  '  impl,',
  '], { cwd: process.cwd(), stdio: \'inherit\', env: process.env });',
  'if (process.env.FIXTURE_DRIFT_PATH) {',
  "  fs.appendFileSync(process.env.FIXTURE_DRIFT_PATH, '\\nDRIFT\\n');",
  '}',
  'if (process.env.FIXTURE_CREATE_PATH) {',
  "  fs.writeFileSync(process.env.FIXTURE_CREATE_PATH, 'created\\n');",
  '}',
  'if (process.env.FIXTURE_STRIP_REL && process.env.FIXTURE_STRIP_TOKEN) {',
  '  const stripPath = path.join(process.cwd(), process.env.FIXTURE_STRIP_REL);',
  "  const token = process.env.FIXTURE_STRIP_TOKEN;",
  "  const lines = fs.readFileSync(stripPath, 'utf8').split('\\n').filter((line) => {",
  "    if (!line.trim().startsWith('|')) return true;",
  "    const first = line.split('|')[1].trim().replace(/^\\*\\*|\\*\\*$/g, '');",
  '    return first !== token;',
  '  });',
  "  fs.writeFileSync(stripPath, lines.join('\\n'));",
  '}',
  'if (process.env.FIXTURE_FORCE_INDICES_EXIT) process.exit(Number(process.env.FIXTURE_FORCE_INDICES_EXIT));',
  'process.exit(typeof result.status === "number" ? result.status : 1);',
  '',
].join('\n');

async function writeMinimalProducerTree(root: string): Promise<void> {
  await fs.copy(
    path.join(REPOSITORY_ROOT, 'cli', 'src'),
    path.join(root, 'cli', 'src'),
    {
      filter: (src: string) => !src.includes(`${path.sep}__tests__`),
    },
  );
  for (const script of [
    'calculate-tokens.ts',
    'generate-indices.ts',
    'generate-capabilities-doc.ts',
  ]) {
    await fs.copy(
      path.join(REPOSITORY_ROOT, 'scripts', script),
      path.join(root, 'scripts', script),
    );
  }
  await fs.copy(
    path.join(REPOSITORY_ROOT, 'scripts', 'generation'),
    path.join(root, 'scripts', 'generation'),
    {
      filter: (src: string) => !src.endsWith('.test.ts'),
    },
  );
}



async function createFixtureRepo(options: FixtureOptions = {}): Promise<string> {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ags-stage-fixture-'));
  try {
    await populateFixtureRepo(root, options);
    return root;
  } catch (error) {
    await fs.remove(root);
    throw error;
  }
}

async function populateFixtureRepo(
  root: string,
  options: FixtureOptions,
): Promise<void> {
  await writeMinimalProducerTree(root);
  await fs.outputFile(
    path.join(root, '.skillsrc'),
    [
      'registry: https://example.invalid/registry',
      'agents:',
      '  - copilot',
      'skills:',
      '  common:',
      '    ref: common-v1',
      'workflows:',
      '  - demo',
      '',
    ].join('\n'),
  );
  await fs.outputFile(
    path.join(root, options.inheritedRootResource ?? 'LICENSE.TXT'),
    LICENSE_TEXT,
  );
  await fs.outputJson(path.join(root, 'skills', 'metadata.json'), {
    categories: { common: {} },
  });
  await fs.outputFile(
    path.join(root, 'skills', 'common', 'common-alpha', 'SKILL.md'),
    SKILL_ALPHA,
  );
  await fs.outputFile(
    path.join(root, 'skills', 'common', 'common-alpha', 'references', 'details.md'),
    'alpha details\n',
  );
  await fs.outputFile(
    path.join(root, 'skills', 'common', 'common-beta', 'SKILL.md'),
    SKILL_BETA,
  );
  await fs.outputFile(
    path.join(root, 'skills', 'specialists', 'specialist-arch', 'SKILL.md'),
    SPECIALIST_ARCH,
  );
  await fs.outputFile(
    path.join(root, '.agents', 'workflows', 'demo.md'),
    '---\ndescription: Demo workflow\n---\n# Demo\n',
  );
  await fs.outputFile(
    path.join(root, 'AGENTS.md'),
    '# Agents\n\n<!-- SKILLS_INDEX_START -->\nold router\n<!-- SKILLS_INDEX_END -->\n',
  );
  await fs.outputFile(
    path.join(root, 'skills', 'README.md'),
    '# Skills\n\n<!-- SKILLS_INDEX_START -->\nold index\n<!-- SKILLS_INDEX_END -->\n',
  );
  if (options.includeMetricsReadme) {
    await fs.outputFile(
      path.join(root, 'README.md'),
      '| **Common Patterns** | Modules | Saving | old | old | old | old | old |\n',
    );
  }
  if (!options.omitBaselineCapabilitiesDoc) {
    await fs.outputFile(
      path.join(root, 'docs', 'agent-capabilities.md'),
      '# Agent Capabilities\n\nold\n',
    );
  } else {
    await fs.ensureDir(path.join(root, 'docs'));
  }
  await fs.outputFile(
    path.join(root, '.github', 'instructions', 'agent-skill-standard-rule.instructions.md'),
    '---\ndescription: rule\n---\nRead AGENTS.md\n',
  );
  await fs.symlink(
    path.join(REPOSITORY_ROOT, 'node_modules'),
    path.join(root, 'node_modules'),
    'junction',
  );
  await linkDependencies(REPOSITORY_ROOT, root);

  for (const script of [
    'scripts/calculate-tokens.ts',
    'scripts/generate-indices.ts',
    'scripts/generate-capabilities-doc.ts',
  ]) {
    const result = await runInStage(
      'node',
      ['--import', 'tsx', path.join(root, script)],
      root,
    );
    if (result.exitCode !== 0) {
      throw new Error(
        `Fixture baseline producer ${script} failed: ${result.stderr || result.stdout}`,
      );
    }
  }
  const plan = await buildGenerationPlan(root);

  if (options.omitMirrorSkill) {
    await fs.remove(
      path.join(root, '.github', 'skills', 'common', options.omitMirrorSkill),
    );
  }
  if (options.omitBaselineCapabilitiesDoc) {
    await fs.remove(path.join(root, 'docs', 'agent-capabilities.md'));
  }

  const cliManaged = new Set([
    ...plan.mirrorFiles.map((item) => item.relPath),
    ...plan.workflowOutputs.map((item) => item.relPath),
    ...plan.specialistOutputs.map((item) => item.relPath),
    ...plan.ruleFiles,
    ...plan.hostCategoryIndexes.map((item) => item.relPath),
  ]);
  const generationEntries: Record<string, { source: string; sha256: string }> = {};
  for (const relPath of plan.declaredFiles) {
    if (cliManaged.has(relPath)) continue;
    const outputPath = path.join(root, relPath);
    const stat = await fs.lstat(outputPath).catch(() => null);
    if (!stat) continue;
    if (!stat.isFile() || stat.isSymbolicLink()) {
      throw new Error(`Fixture baseline output "${relPath}" is not a regular file.`);
    }
    generationEntries[relPath] = {
      source: 'fixture:real-producer-baseline',
      sha256: sha256(await fs.readFile(outputPath)),
    };
  }
  const lockPath = path.join(root, '.skills-lock.json');
  const lock = await fs.readJson(lockPath);
  lock.generation = { version: 1, entries: generationEntries };
  await fs.writeJson(lockPath, lock, { spaces: 2 });

  if (
    options.mutateDuringIndices ||
    options.failAfterIndices ||
    options.driftSourceDuringIndices
  ) {
    await fs.move(
      path.join(root, 'scripts', 'generate-indices.ts'),
      path.join(root, 'scripts', 'generate-indices.impl.ts'),
    );
    await fs.outputFile(
      path.join(root, 'scripts', 'generate-indices.ts'),
      GENERATE_INDICES_WRAPPER,
    );
  }
}

async function withFixture(
  options: FixtureOptions,
  body: (root: string) => Promise<void>,
): Promise<void> {
  const root = await createFixtureRepo(options);
  const previousCwd = process.cwd();
  process.chdir(root);
  try {
    await body(root);
  } finally {
    process.chdir(previousCwd);
    await fs.remove(root);
  }
}

async function withEnv<T>(
  values: Record<string, string>,
  body: () => Promise<T>,
): Promise<T> {
  for (const [key, value] of Object.entries(values)) {
    process.env[key] = value;
  }
  try {
    return await body();
  } finally {
    for (const key of Object.keys(values)) delete process.env[key];
  }
}

async function git(cwd: string, args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn('git', args, { cwd, shell: false });
    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr?.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code !== 0) reject(new Error(`git ${args.join(' ')} failed: ${stderr}`));
      else resolve(stdout.trim());
    });
  });
}
async function commitFixtureBase(root: string): Promise<string> {
  await git(root, ['init', '--quiet']);
  await git(root, ['config', 'user.name', 'Fixture']);
  await git(root, ['config', 'user.email', 'fixture@example.invalid']);
  await git(root, [
    'add',
    '--all',
    '--',
    '.skillsrc',
    'AGENTS.md',
    'LICENSE.TXT',
    '.agents',
    '.github',
    'docs',
    'skills',
    'scripts',
    'cli',
  ]);
  await git(root, ['commit', '--quiet', '-m', 'generated baseline']);
  return git(root, ['rev-parse', 'HEAD']);

}

test('unchanged unowned outputs pass check without creating an ownership manifest', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    await fs.remove(path.join(root, '.skills-lock.json'));

    const checked = await runIsolatedGeneration({ repoRoot: root, checkOnly: true });

    assert.equal(checked.success, true, checked.error ?? '');
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});

test('explicit base adoption proves producer bytes and records generation authority', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));

    const adopted = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(adopted.success, true, adopted.error ?? '');
    assert.ok(adopted.copiedBackFiles.includes('.skills-lock.json'));
    const lock = await fs.readJson(path.join(root, '.skills-lock.json'));
    assert.equal(
      lock.entries['.github/skills/common/common-alpha/LICENSE.TXT'].source,
      'skill:common/common-alpha@common-v1',
    );
    assert.ok(lock.generation.entries['AGENTS.md']);
    assert.equal(
      lock.generation.entries[
        '.github/skills/common/common-alpha/LICENSE.TXT'
      ],
      undefined,
    );
  });
});
test('base adoption proves a README metrics row by forcing the prior producer to rewrite it', async () => {
  await withFixture({ includeMetricsReadme: true }, async (root) => {
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    const sourcePath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    await fs.appendFile(sourcePath, '\nChanged candidate source for metrics.\n');

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, true, result.error ?? '');
    assert.ok(result.copiedBackFiles.includes('README.md'));
    const readme = await fs.readFile(path.join(root, 'README.md'), 'utf8');
    assert.doesNotMatch(readme, /AGS-BASE-PROOF/);
    const lock = await fs.readJson(path.join(root, '.skills-lock.json'));
    assert.equal(
      lock.generation.entries['README.md'].sha256,
      sha256(await fs.readFile(path.join(root, 'README.md'))),
    );
  });
});

test('base adoption rejects a mixed AGENTS output the prior producer cannot rewrite', async () => {
  await withFixture({}, async (root) => {
    const agentsPath = path.join(root, 'AGENTS.md');
    await fs.writeFile(
      agentsPath,
      '# Authored agents context\n\nNo generated index markers.\n',
    );
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    const baseBytes = await fs.readFile(agentsPath);

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(
      result.error ?? '',
      /Adoption refused for "AGENTS\.md": pinned-base producer cannot prove a writable generated section/,
    );
    assert.deepEqual(await fs.readFile(agentsPath), baseBytes);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});

test('base adoption refuses an output absent from the tracked base', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    await commitFixtureBase(root);
    await git(root, ['rm', '--cached', '--quiet', 'docs/agent-capabilities.md']);
    await git(root, ['commit', '--quiet', '-m', 'remove generated capabilities output']);
    const base = await git(root, ['rev-parse', 'HEAD']);
    await fs.remove(path.join(root, '.skills-lock.json'));

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(
      result.error ?? '',
      /does not contain tracked regular output "docs\/agent-capabilities\.md"/,
    );
    assert.ok(await fs.pathExists(path.join(root, 'docs', 'agent-capabilities.md')));
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});
test('base adoption rejects changed tracked output bytes before publication', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    const promptPath = path.join(root, '.github', 'prompts', 'demo.prompt.md');
    await fs.appendFile(promptPath, '\nlocal edit\n');
    const edited = await fs.readFile(promptPath, 'utf8');

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /current bytes do not match/);
    assert.equal(await fs.readFile(promptPath, 'utf8'), edited);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});
test('base adoption rejects a base-tracked output made untracked in the current index', async () => {
  await withFixture({}, async (root) => {
    const base = await commitFixtureBase(root);
    const relPath = '.github/skills/common/common-alpha/SKILL.md';
    const outputPath = path.join(root, relPath);
    const original = await fs.readFile(outputPath, 'utf8');
    await git(root, ['rm', '--cached', '--quiet', relPath]);
    await fs.remove(path.join(root, '.skills-lock.json'));

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /current index is untracked or differs from the recorded base/);
    assert.equal(await fs.readFile(outputPath, 'utf8'), original);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});
test('base adoption updates outputs from changed canonical skill inputs', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    const sourcePath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    const edited = SKILL_ALPHA.replace('Alpha skill', 'Revised Alpha skill');
    await fs.writeFile(sourcePath, edited);

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, true, result.error ?? '');
    assert.ok(
      result.copiedBackFiles.includes(
        '.github/skills/common/common-alpha/SKILL.md',
      ),
    );
    const lock = await fs.readJson(path.join(root, '.skills-lock.json'));
    assert.ok(lock.generation.entries['skills/metadata.json']);
    assert.ok(await fs.pathExists(path.join(result.logPath, '..', 'adoption', 'proof.json')));
  });
});
test('base adoption rejects a tracked output poisoned before the recorded base', async () => {
  await withFixture({}, async (root) => {
    const poisonedPath = path.join(
      root,
      '.github',
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    await fs.appendFile(poisonedPath, '\npoisoned historical output\n');
    const poisoned = await fs.readFile(poisonedPath, 'utf8');
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /Pinned-base producer output differs from base blob/);
    assert.equal(await fs.readFile(poisonedPath, 'utf8'), poisoned);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});
test('base adoption reconstructs generated metadata instead of trusting its retained bytes', async () => {
  await withFixture({}, async (root) => {
    const metadataPath = path.join(root, 'skills', 'metadata.json');
    const metadata = await fs.readJson(metadataPath);
    metadata.categories.common.token_metrics = { poisoned: 'historical-output' };
    await fs.writeJson(metadataPath, metadata, { spaces: 2 });
    const poisoned = await fs.readFile(metadataPath);
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(
      result.error ?? '',
      /Pinned-base producer output differs from base blob for "skills\/metadata\.json"/,
    );
    assert.deepEqual(await fs.readFile(metadataPath), poisoned);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});

test('normal CLI refresh preserves generation-owned files and ledger after adoption', async () => {
  await withFixture({}, async (root) => {
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    const canonicalSkillPath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    const adoptedSkill = SKILL_ALPHA.replace('Alpha skill', 'Adopted Alpha skill');
    await fs.writeFile(canonicalSkillPath, adoptedSkill);

    const adopted = await runIsolatedGeneration({
      repoRoot: root,
      adoptBase: base,
    });
    assert.equal(adopted.success, true, adopted.error ?? '');

    const generatedPaths = [
      'AGENTS.md',
      'skills/README.md',
      'skills/metadata.json',
      'skills/common/_INDEX.md',
      'docs/agent-capabilities.md',
    ];
    const generatedBefore = new Map(
      await Promise.all(
        generatedPaths.map(async (relPath) => [
          relPath,
          await fs.readFile(path.join(root, relPath)),
        ] as const),
      ),
    );
    const lockBefore = await fs.readJson(path.join(root, '.skills-lock.json'));
    assert.ok(lockBefore.generation.entries['skills/metadata.json']);

    const refreshedSkill = adoptedSkill.replace(
      'Adopted Alpha skill',
      'CLI refreshed Alpha skill',
    );
    await fs.writeFile(canonicalSkillPath, refreshedSkill);
    const config = {
      registry: 'https://example.invalid/registry',
      agents: [Agent.Copilot],
      skills: { common: { ref: 'common-v1' } },
      workflows: [],
      custom_overrides: [],
    } as SkillConfig;
    const skills: CollectedSkill[] = [
      {
        category: 'common',
        skill: 'common-alpha',
        files: [
          { name: 'SKILL.md', content: refreshedSkill },
          { name: 'references/details.md', content: 'alpha details\n' },
          { name: 'LICENSE.TXT', content: LICENSE_TEXT },
        ],
      },
      {
        category: 'common',
        skill: 'common-beta',
        files: [
          { name: 'SKILL.md', content: SKILL_BETA },
          { name: 'LICENSE.TXT', content: LICENSE_TEXT },
        ],
      },
    ];
    const sync = new SyncService();
    await sync.beginInstall(config, { dryRun: false, force: [] });
    await sync.writeSkills(skills, config);
    await sync.completeInstall(config, {
      skills,
      workflows: [],
      specialistsOk: true,
    });

    assert.equal(
      await fs.readFile(
        path.join(root, '.github', 'skills', 'common', 'common-alpha', 'SKILL.md'),
        'utf8',
      ),
      refreshedSkill,
    );
    for (const [relPath, bytes] of generatedBefore) {
      assert.deepEqual(await fs.readFile(path.join(root, relPath)), bytes);
    }
    const lockAfter = await fs.readJson(path.join(root, '.skills-lock.json'));
    assert.deepEqual(lockAfter.generation, lockBefore.generation);
    assert.ok(
      lockAfter.entries['.github/skills/common/common-alpha/SKILL.md'],
    );
  });
});
test('base adoption rejects changed source/custom-overrides configuration', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    const base = await commitFixtureBase(root);
    await fs.remove(path.join(root, '.skills-lock.json'));
    await fs.appendFile(
      path.join(root, '.skillsrc'),
      '\noverrides:\n  - .github/skills/common/common-alpha/SKILL.md\n',
    );

    const result = await runIsolatedGeneration({ repoRoot: root, adoptBase: base });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /source\/custom-overrides mismatch at "\.skillsrc"/);
    assert.equal(await fs.pathExists(path.join(root, '.skills-lock.json')), false);
  });
});

test('edited owned specialist output is preserved and blocks publication', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    const specialistPath = path.join(
      root,
      '.github',
      'copilot-agents',
      'specialist-arch.instructions.md',
    );
    await fs.appendFile(specialistPath, '\nlocal edit\n');
    const edited = await fs.readFile(specialistPath, 'utf8');

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /Edited-owned output/);
    assert.equal(await fs.readFile(specialistPath, 'utf8'), edited);
  });
});

test('differing unowned output blocks publication without adoption', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');
    await fs.remove(path.join(root, '.skills-lock.json'));
    const promptPath = path.join(root, '.github', 'prompts', 'demo.prompt.md');
    await fs.appendFile(promptPath, '\nlocal edit\n');
    const edited = await fs.readFile(promptPath, 'utf8');

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /lack trusted ownership or explicit base proof/);
    assert.equal(await fs.readFile(promptPath, 'utf8'), edited);
  });
});
test('edited owned bridge and category index outputs are preserved', async () => {
  for (const relPath of [
    '.github/instructions/agent-skill-standard-rule.instructions.md',
    '.github/skills/common/_INDEX.md',
  ]) {
    await withFixture({}, async (root) => {
      const applied = await runIsolatedGeneration({ repoRoot: root });
      assert.equal(applied.success, true, applied.error ?? '');
      const destination = path.join(root, relPath);
      await fs.appendFile(destination, '\nlocal edit\n');
      const edited = await fs.readFile(destination, 'utf8');

      const result = await runIsolatedGeneration({ repoRoot: root });

      assert.equal(result.success, false, relPath);
      assert.match(result.error ?? '', /Edited-owned output/);
      assert.equal(await fs.readFile(destination, 'utf8'), edited);
    });
  }
});


test('a real generator child that exits nonzero blocks all copy-back', async () => {
  await withFixture({ failAfterIndices: true }, async (root) => {
    const metadataBefore = await fs.readFile(
      path.join(root, 'skills', 'metadata.json'),
      'utf8',
    );
    const result = await withEnv(
      { FIXTURE_FORCE_INDICES_EXIT: '23' },
      () => runIsolatedGeneration({ repoRoot: root }),
    );

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /generate-indices failed in stage with exit code 23/);
    assert.deepEqual(result.copiedBackFiles, []);
    assert.equal(
      await fs.readFile(path.join(root, 'skills', 'metadata.json'), 'utf8'),
      metadataBefore,
    );
  });
});
test('candidate canonical source drift blocks publication after staged generation', async () => {
  await withFixture({ driftSourceDuringIndices: true }, async (root) => {
    const sourcePath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    const sourceBefore = await fs.readFile(sourcePath, 'utf8');
    const metadataPath = path.join(root, 'skills', 'metadata.json');
    const metadataBefore = await fs.readFile(metadataPath, 'utf8');

    const result = await withEnv(
      { FIXTURE_DRIFT_PATH: sourcePath },
      () => runIsolatedGeneration({ repoRoot: root }),
    );

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /Candidate source inventory drifted/);
    assert.equal(await fs.readFile(sourcePath, 'utf8'), `${sourceBefore}\nDRIFT\n`);
    assert.equal(await fs.readFile(metadataPath, 'utf8'), metadataBefore);
    assert.deepEqual(result.copiedBackFiles, []);
  });
});


test('apply publishes staged outputs with real producer formats and inherited license resources', async () => {
  await withFixture({}, async (root) => {
    const sourcePath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    await fs.writeFile(
      sourcePath,
      SKILL_ALPHA.replace('Alpha skill', 'Revised Alpha skill'),
    );
    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, true, result.error ?? '');
    assert.ok(result.copiedBackFiles.includes('skills/metadata.json'));
    assert.ok(
      result.copiedBackFiles.includes('.github/skills/common/_INDEX.md'),
    );
    assert.ok(
      result.copiedBackFiles.includes(
        '.github/skills/common/common-alpha/LICENSE.TXT',
      ),
    );
    assert.ok(
      result.copiedBackFiles.includes('.github/prompts/demo.prompt.md'),
    );
    assert.ok(
      result.copiedBackFiles.includes(
        '.github/copilot-agents/specialist-arch.instructions.md',
      ),
    );
    assert.deepEqual(result.verifiedFiles, result.copiedBackFiles);

    const hostIndex = await fs.readFile(
      path.join(root, '.github', 'skills', 'common', '_INDEX.md'),
      'utf8',
    );
    const rows = parseCategoryIndexRows(hostIndex);
    assert.deepEqual(rows.malformed, []);
    assert.deepEqual(rows.duplicates, []);
    assert.deepEqual(rows.ids.sort(), ['common-alpha', 'common-beta']);

    const canonicalIndex = parseCategoryIndexRows(
      await fs.readFile(path.join(root, 'skills', 'common', '_INDEX.md'), 'utf8'),
    );
    assert.deepEqual(canonicalIndex.ids.sort(), ['common-alpha', 'common-beta']);

    assert.equal(
      await fs.readFile(
        path.join(root, '.github', 'skills', 'common', 'common-alpha', 'LICENSE.TXT'),
        'utf8',
      ),
      LICENSE_TEXT,
    );

    const receipt = await fs.readJson(result.receiptPath);
    assert.equal(receipt.status, 'APPLIED');
    assert.deepEqual(receipt.copiedBackFiles, result.copiedBackFiles);
  });
});

test('root LICENSE and NOTICE resource variants inherit through real producers', async () => {
  for (const resource of [
    'LICENSE',
    'license',
    'LICENSE.md',
    'license.txt',
    'NOTICE',
    'notice.md',
    'NOTICE.txt',
    'notice.TXT',
  ]) {
    await withFixture({ inheritedRootResource: resource }, async (root) => {
      const result = await runIsolatedGeneration({ repoRoot: root });

      assert.equal(result.success, true, result.error ?? '');
      assert.equal(
        await fs.readFile(
          path.join(
            root,
            '.github',
            'skills',
            'common',
            'common-alpha',
            resource,
          ),
          'utf8',
        ),
        LICENSE_TEXT,
      );
    });
  }
});

test('a missing selected mirror inventory is seeded before index bootstrap and published', async () => {
  await withFixture({ omitMirrorSkill: 'common-beta' }, async (root) => {
    assert.equal(
      await fs.pathExists(
        path.join(root, '.github', 'skills', 'common', 'common-beta'),
      ),
      false,
    );

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, true, result.error ?? '');
    assert.equal(
      await fs.readFile(
        path.join(
          root,
          '.github',
          'skills',
          'common',
          'common-beta',
          'SKILL.md',
        ),
        'utf8',
      ),
      SKILL_BETA,
    );
    assert.equal(
      await fs.readFile(
        path.join(root, '.github', 'skills', 'common', 'common-beta', 'LICENSE.TXT'),
        'utf8',
      ),
      LICENSE_TEXT,
    );
    const hostRows = parseCategoryIndexRows(
      await fs.readFile(
        path.join(root, '.github', 'skills', 'common', '_INDEX.md'),
        'utf8',
      ),
    );
    assert.deepEqual(hostRows.ids.sort(), ['common-alpha', 'common-beta']);
  });
});

test('check mode passes after apply and copies nothing', async () => {
  await withFixture({}, async (root) => {
    const applied = await runIsolatedGeneration({ repoRoot: root });
    assert.equal(applied.success, true, applied.error ?? '');

    const checked = await runIsolatedGeneration({
      repoRoot: root,
      checkOnly: true,
    });
    assert.equal(checked.success, true, checked.error ?? '');
    assert.deepEqual(checked.copiedBackFiles, []);
    assert.equal((await fs.readJson(checked.receiptPath)).status, 'PASS');
  });
});

test('check mode fails closed on stale prepared outputs and leaves destinations untouched', async () => {
  await withFixture({}, async (root) => {
    const metadataPath = path.join(root, 'skills', 'metadata.json');
    const sourcePath = path.join(
      root,
      'skills',
      'common',
      'common-alpha',
      'SKILL.md',
    );
    const before = await fs.readFile(metadataPath, 'utf8');
    await fs.appendFile(sourcePath, '\nChanged canonical content\n');

    const result = await runIsolatedGeneration({
      repoRoot: root,
      checkOnly: true,
    });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /stale/i);
    assert.deepEqual(result.copiedBackFiles, []);
    assert.equal(await fs.readFile(metadataPath, 'utf8'), before);
    assert.equal((await fs.readJson(result.receiptPath)).status, 'FAILED');
  });
});

test('an edited owned mirror is preserved and reported as a conflict, not overwritten', async () => {
  await withFixture({}, async (root) => {
    const mirrorPath = path.join(
      root,
      '.github',
      'skills',
      'common',
      'common-beta',
      'SKILL.md',
    );
    const editedBytes = '---\nname: common-beta\ndescription: locally edited\n---\n# Beta\n';
    await fs.outputFile(mirrorPath, editedBytes);
    const metadataPath = path.join(root, 'skills', 'metadata.json');
    const metadataBefore = await fs.readFile(metadataPath, 'utf8');

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /\[conflict\]/);
    assert.match(result.error ?? '', /common-beta\/SKILL\.md/);
    assert.deepEqual(result.copiedBackFiles, []);
    assert.equal(await fs.readFile(mirrorPath, 'utf8'), editedBytes);
    assert.equal(await fs.readFile(metadataPath, 'utf8'), metadataBefore);
  });
});

test('a configured exclusion that still appears in a host index is rejected as unexpected discovery', async () => {
  await withFixture({}, async (root) => {
    await fs.outputFile(
      path.join(root, '.skillsrc'),
      [
        'registry: https://example.invalid/registry',
        'agents:',
        '  - copilot',
        'skills:',
        '  common:',
        '    ref: common-v1',
        '    exclude:',
        '      - common-beta',
        'workflows:',
        '  - demo',
        '',
      ].join('\n'),
    );

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /advertises unexpected ids/);
    assert.match(result.error ?? '', /common-beta/);
    assert.deepEqual(result.copiedBackFiles, []);
  });
});

test('a configured workflow whose source is absent is rejected before staging', async () => {
  await withFixture({}, async (root) => {
    await fs.outputFile(
      path.join(root, '.skillsrc'),
      [
        'registry: https://example.invalid/registry',
        'agents:',
        '  - copilot',
        'skills:',
        '  common:',
        '    ref: common-v1',
        'workflows:',
        '  - demo',
        '  - ghost',
        '',
      ].join('\n'),
    );

    const result = await runIsolatedGeneration({ repoRoot: root });

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /workflow source \.agents\/workflows\/ghost\.md/);
    assert.ok(!(await fs.readFile(result.logPath, 'utf8')).includes('[calculate-tokens]'));
  });
});

test('a canonical index row removed after generation is reported as an omission', async () => {
  await withFixture({ mutateDuringIndices: true }, async (root) => {
    const result = await withEnv(
      {
        FIXTURE_STRIP_REL: path.join('skills', 'common', '_INDEX.md'),
        FIXTURE_STRIP_TOKEN: 'common-beta',
      },
      () => runIsolatedGeneration({ repoRoot: root }),
    );

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /canonical skills\/common\/_INDEX\.md omits ids: common-beta/);
    assert.deepEqual(result.copiedBackFiles, []);
  });
});

test('destination drift during generation aborts the whole copy-back', async () => {
  await withFixture({ mutateDuringIndices: true }, async (root) => {
    const agentsPath = path.join(root, 'AGENTS.md');
    const metadataPath = path.join(root, 'skills', 'metadata.json');
    const metadataBefore = await fs.readFile(metadataPath, 'utf8');

    const result = await withEnv(
      { FIXTURE_DRIFT_PATH: agentsPath },
      () => runIsolatedGeneration({ repoRoot: root }),
    );

    assert.equal(result.success, false);
    assert.match(result.error ?? '', /Concurrent drift detected/);
    assert.deepEqual(result.copiedBackFiles, []);
    assert.equal(await fs.readFile(metadataPath, 'utf8'), metadataBefore);
  });
});

test('an absent declared destination that appears during generation aborts', async () => {
  await withFixture(
    { mutateDuringIndices: true, omitBaselineCapabilitiesDoc: true },
    async (root) => {
      const capabilitiesPath = path.join(root, 'docs', 'agent-capabilities.md');
      assert.equal(await fs.pathExists(capabilitiesPath), false);

      const result = await withEnv(
        { FIXTURE_CREATE_PATH: capabilitiesPath },
        () => runIsolatedGeneration({ repoRoot: root }),
      );

      assert.equal(result.success, false);
      assert.match(result.error ?? '', /Concurrent drift detected/);
      assert.deepEqual(result.copiedBackFiles, []);
      assert.equal(await fs.readFile(capabilitiesPath, 'utf8'), 'created\n');
    },
  );
});

test('a post-rename verification failure still reports the renamed destination', async (t) => {
  await withFixture({}, async (root) => {
    const realRename = fs.rename;
    const renameMock = t.mock.method(
      fs,
      'rename',
      async (from: string, to: string) => {
        await realRename(from, to);
        await fs.appendFile(to, 'CORRUPT\n');
      },
    );
    try {
      const result = await runIsolatedGeneration({ repoRoot: root });

      assert.equal(result.success, false);
      assert.match(result.error ?? '', /Post-copy verification failed/);
      assert.equal(result.copiedBackFiles.length, 1);
      const renamed = result.copiedBackFiles[0];
      assert.deepEqual(result.verifiedFiles, []);
      assert.match(
        await fs.readFile(path.join(root, renamed), 'utf8'),
        /CORRUPT\n$/,
      );

      const receipt = await fs.readJson(result.receiptPath);
      assert.equal(receipt.status, 'FAILED');
      assert.deepEqual(receipt.appliedFiles, result.copiedBackFiles);
      assert.deepEqual(receipt.verifiedFiles, []);
    } finally {
      renameMock.mock.restore();
    }
  });
});
test('a post-rename ownership-manifest failure reports the ledger as applied but unverified', async (t) => {
  await withFixture({}, async (root) => {
    await fs.writeFile(
      path.join(root, 'skills', 'common', 'common-alpha', 'SKILL.md'),
      SKILL_ALPHA.replace('Alpha skill', 'Ledger verification Alpha'),
    );
    const realRename = fs.rename;
    const renameMock = t.mock.method(
      fs,
      'rename',
      async (from: string, to: string) => {
        await realRename(from, to);
        if (to === path.join(root, '.skills-lock.json')) {
          await fs.appendFile(to, '\nCORRUPT\n');
        }
      },
    );
    try {
      const result = await runIsolatedGeneration({ repoRoot: root });

      assert.equal(result.success, false);
      assert.match(result.error ?? '', /Ownership manifest bytes differ after atomic replacement/);
      assert.ok(result.copiedBackFiles.includes('.skills-lock.json'));
      assert.ok(!result.verifiedFiles.includes('.skills-lock.json'));
      const receipt = await fs.readJson(result.receiptPath);
      assert.equal(receipt.status, 'FAILED');
      assert.ok(receipt.appliedFiles.includes('.skills-lock.json'));
      assert.ok(!receipt.verifiedFiles.includes('.skills-lock.json'));
    } finally {
      renameMock.mock.restore();
    }
  });
});

test('a repeated attempt id never overwrites or reuses prior evidence', async () => {
  await withFixture({}, async (root) => {
    const first = await runIsolatedGeneration({
      repoRoot: root,
      attemptId: 'fixed-attempt',
    });
    assert.equal(first.success, true, first.error ?? '');

    const logBefore = await fs.readFile(first.logPath, 'utf8');
    const receiptBefore = await fs.readFile(first.receiptPath, 'utf8');

    await assert.rejects(
      () =>
        runIsolatedGeneration({ repoRoot: root, attemptId: 'fixed-attempt' }),
      /Refusing to reuse or overwrite prior attempt evidence/,
    );

    assert.equal(await fs.readFile(first.logPath, 'utf8'), logBefore);
    assert.equal(await fs.readFile(first.receiptPath, 'utf8'), receiptBefore);
  });
});

test('a pre-existing attempt directory without a log is still refused', async () => {
  await withFixture({}, async (root) => {
    const logDir = path.join(root, 'artifacts', 'generation-logs', 'taken');
    await fs.outputJson(path.join(logDir, 'receipt.json'), { status: 'OLD' });

    await assert.rejects(
      () => runIsolatedGeneration({ repoRoot: root, attemptId: 'taken' }),
      /Refusing to reuse or overwrite prior attempt evidence/,
    );
    assert.deepEqual(await fs.readJson(path.join(logDir, 'receipt.json')), {
      status: 'OLD',
    });
  });
});

test('the generator entrypoint refuses a foreign working directory before writing', async () => {
  await withFixture({}, async (root) => {
    const child = spawn(
      process.execPath,
      [
        '--import',
        'tsx',
        path.join(REPOSITORY_ROOT, 'scripts', 'generation', 'index.ts'),
        '--check',
      ],
      { cwd: root, env: { ...process.env, CI: 'true' } },
    );
    let stderr = '';
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    const exitCode = await new Promise<number>((resolve) => {
      child.on('close', (code) => resolve(code ?? 1));
    });

    assert.equal(exitCode, 1);
    assert.match(stderr, /foreign working directory/);
    assert.equal(
      await fs.pathExists(path.join(root, 'artifacts', 'generation-logs')),
      false,
    );
  });
});

test('the public entrypoint check leaves a no-change real-producer fixture and its manifest untouched', async () => {
  await withFixture({}, async (root) => {
    const watched = [
      'AGENTS.md',
      '.github/skills/common/common-alpha/SKILL.md',
      '.skills-lock.json',
    ];
    const before = new Map<string, Buffer>();
    for (const relPath of watched) {
      before.set(relPath, await fs.readFile(path.join(root, relPath)));
    }

    const child = spawn(
      process.execPath,
      [
        '--import',
        'tsx',
        path.join(root, 'scripts', 'generation', 'index.ts'),
        '--check',
      ],
      { cwd: root, env: { ...process.env, CI: 'true' } },
    );
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    const exitCode = await new Promise<number>((resolve) => {
      child.on('close', (code) => resolve(code ?? 1));
    });

    assert.equal(exitCode, 0, `${stdout}\n${stderr}`);

    for (const relPath of watched) {
      const expected = before.get(relPath);
      assert.ok(expected, `missing baseline bytes for ${relPath}`);
      assert.ok(
        (await fs.readFile(path.join(root, relPath))).equals(expected),
        `${relPath} changed under --check`,
      );
    }

    const receiptMatch = /Receipt: (.+)$/m.exec(stdout);
    assert.ok(receiptMatch, `no receipt path in output: ${stdout}`);
    const receipt = await fs.readJson(receiptMatch[1].trim());
    assert.equal(receipt.status, 'PASS');
    assert.equal(receipt.checkOnly, true);
  });
});

test('an unconfigured symlinked category is rejected before any generator runs', async () => {
  await withFixture({}, async (root) => {
    const external = await fs.mkdtemp(path.join(os.tmpdir(), 'ags-external-'));
    try {
      await fs.outputFile(
        path.join(external, 'rogue-skill', 'SKILL.md'),
        '---\nname: rogue-skill\ndescription: external\n---\n# Rogue\n',
      );
      await fs.symlink(external, path.join(root, 'skills', 'extra-category'), 'junction');

      const result = await runIsolatedGeneration({ repoRoot: root });

      assert.equal(result.success, false);
      assert.match(result.error ?? '', /Source symlink not permitted/);
      assert.ok(
        !(await fs.readFile(result.logPath, 'utf8')).includes('[calculate-tokens]'),
      );
      assert.equal(
        await fs.readFile(
          path.join(external, 'rogue-skill', 'SKILL.md'),
          'utf8',
        ),
        '---\nname: rogue-skill\ndescription: external\n---\n# Rogue\n',
      );
      assert.deepEqual(
        (await fs.readdir(external)).sort(),
        ['rogue-skill'],
      );
    } finally {
      await fs.remove(external);
    }
  });
});

test('copySourceToStage keeps mirrors while excluding .git, .agent, artifacts and dependencies', async () => {
  const source = await fs.mkdtemp(path.join(os.tmpdir(), 'stage-copy-src-'));
  const destination = await fs.mkdtemp(
    path.join(os.tmpdir(), 'stage-copy-dest-'),
  );
  const stage = path.join(destination, 'isolated-stage');

  try {
    await fs.outputFile(path.join(source, 'AGENTS.md'), '# root\n');
    await fs.outputFile(
      path.join(source, '.agents', 'skills', 'common', '_INDEX.md'),
      'mirror\n',
    );
    await fs.outputFile(path.join(source, '.git', 'HEAD'), 'ref\n');
    await fs.outputFile(path.join(source, '.agent', 'sdd', 'report.md'), 'sdd\n');
    await fs.outputFile(path.join(source, 'artifacts', 'log.txt'), 'log\n');
    await fs.outputFile(
      path.join(source, 'node_modules', 'left-pad', 'index.js'),
      'module\n',
    );

    await copySourceToStage(source, stage);

    assert.equal(await fs.pathExists(path.join(stage, 'AGENTS.md')), true);
    assert.equal(
      await fs.pathExists(
        path.join(stage, '.agents', 'skills', 'common', '_INDEX.md'),
      ),
      true,
    );
    assert.equal(await fs.pathExists(path.join(stage, '.git')), false);
    assert.equal(await fs.pathExists(path.join(stage, '.agent')), false);
    assert.equal(await fs.pathExists(path.join(stage, 'artifacts')), false);
    assert.equal(await fs.pathExists(path.join(stage, 'node_modules')), false);
  } finally {
    await fs.remove(source);
    await fs.remove(destination);
  }
});
