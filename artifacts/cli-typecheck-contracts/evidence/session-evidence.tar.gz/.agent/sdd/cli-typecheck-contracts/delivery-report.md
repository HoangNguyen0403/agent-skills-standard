# Delivery report — CLI typecheck contract repair

- Slug: `cli-typecheck-contracts`
- Approved plan: `docs/prd/prd-plan-cli-typecheck-contracts.md` (`fd0dfb07ec87f04a282b15a3030d2c716be60fee4597e65458b9e675f7beb584`)
- Execution plan: `.agent/sdd/cli-typecheck-contracts/execution-plan.md` (`8404f825ae8658…`)
- Source revision: `1c79a7edb22b768ad5362e2e10766df2978e8642` plus the uncommitted repair snapshot reviewed at `source-review.md`
- Date: 2026-11-06
- Status: **delivered in the repository, with every approved compiler, runtime and preservation criterion observed PASS.** Not verified complete as a delivery record, not accepted, not merged, not released. Only the final documentation/evidence review and the scoped document audit remain pending. Human acceptance, release, live efficacy, persistent-client, minimum-Node and Windows claims are not made.

## 1. Observed receipts

All receipts are `schema_version: 1` JSON records with a sibling `.log` in `.agent/sdd/cli-typecheck-contracts/`. Timestamps below are the recorded `started_at`/`completed_at` values, not estimates.

| Receipt | Command (cwd) | Result |
| --- | --- | --- |
| `compiler-cli.json` | `pnpm exec tsc --noEmit` (`cli`) | **FAIL**, exit 2, 1 diagnostic — `cli/src/commands/__tests__/UninstallCommand.spec.ts:56` broad confirmation mock; retained as history |
| `compiler-cli-final.json` | `pnpm exec tsc --noEmit` (`cli`) | **PASS**, exit 0, no diagnostics — 2026-11-06T07:03:13.590Z → 07:03:15.434Z |
| `compiler-mcp.json` | `pnpm exec tsc --noEmit` (`mcp`) | **PASS**, exit 0 |
| `focused-cli.json` | `vitest run` over 10 owned spec files (`cli`) | exit 0, 10 files, 488 tests — **predates** the confirmation-mock correction, so it is not the corrected-source proof |
| `full-cli.json` | `vitest run` (`cli`) | **PASS**, exit 0, 71 files, 1554 tests |
| `full-mcp.json` | `vitest run` (`mcp`) | **PASS**, exit 0, 33 files, 979 passed \| 4 skipped (983) |
| `full-generator.json` | `node --import tsx --test scripts/generation/isolated-stage.test.ts` (root) | **PASS**, exit 0, 95 tests |
| `preservation-evals.json` | `pnpm test:evals` (root) | **PASS**, exit 0, 477 tests |
| `preservation-reporting.json` | `node --import tsx --test scripts/outcome/schema.test.ts scripts/outcome/index.test.ts scripts/trace/parse.test.ts scripts/trace/graph.test.ts scripts/trace/index.test.ts` (root) | **PASS**, exit 0, 92 tests — the five test files exactly as recorded in the receipt; not a suite-wide glob |
| `smoke-subprocess.json` | `node .agent/sdd/cli-typecheck-contracts/subprocess-smoke.mjs` (root) | **PASS**, exit 0 — 4 scenarios (success, nonzero with stderr, nonzero without stderr, missing executable); each asserted adapter outcome plus temporary-manifest removal |
| `smoke-scope-final.json` | `node .agent/sdd/cli-typecheck-contracts/scope-smoke.mjs` (root) | **PASS**, exit 0 — actual Commander adapter, 5 invocations: `mcp scope user`, `mcp scope project --scope user`, `mcp scope snippets-only`, `mcp scope --scope user`, `mcp scope bogus` |
| `smoke-routing.json` | `node .agent/sdd/cli-typecheck-contracts/routing-smoke.mjs` (root) | **FAIL**, exit 1 — 12 PASS, 1 FAIL; retained as confounded-fixture history, see §3 |
| `smoke-routing-final.json` | same script, corrected fixture (root) | **PASS**, exit 0, 14/14 fixtures — 2026-11-06T07:12:14.332Z → 07:12:14.491Z, `ROUTING SMOKE OK` |
| `root-generation.json` | `node --import tsx scripts/generation/index.ts` (root) | **PASS**, exit 0, recorded output "Copied back: none (up to date)" — establishes that no generated resource was copied back into the tree; it is not a proof that no byte anywhere was written |
| `root-generation-check.json` | `… --check` (root) | **PASS**, exit 0 — separate parity check over the generated outputs |
| `root-consumer.json` | `node .agent/sdd/cli-typecheck-contracts/consumer-smoke.mjs` (root) | **PASS**, exit 0 — same-root source MCP consumer returned the canonical decision skill plus both workflow bodies; linked references read from the filesystem |
| `final-trace.json` | `pnpm audit:trace --slug critical-thinking-agent-workflows --required --json` (root) | **PASS**, exit 0 — 2026-11-06T07:17:05.729Z → 07:17:06.343Z |
| `final-outcome.json` | `pnpm audit:outcome --records --required --slug cli-typecheck-contracts --workflow session-report --run-id 20261106-session-report --dir artifacts/runs/cli-typecheck-contracts --json` (root) | **PASS**, exit 0 — 2026-11-06T07:17:06.406Z → 07:17:07.024Z |

Review records:

- `plan-review.json` — independent reviewer `33a1fcbc…`, "No blocking plan findings", architecture and security sufficient at design scope; explicitly a separate reviewer context, no host provenance, no human or release authority, no commands run.
- `source-review.md` — independent 14-file cumulative review of `1c79a7ed…`..WORKSPACE, `APPROVE`.
- `.agent/sdd/cli-typecheck-contracts/task-1-report.md`, `task-2-report.md`, `task-3-report.md` — per-slice frozen worker reports.

## 2. Test-count movement

The CLI suite baseline for the completed critical-thinking feature was 1555 tests in 71 files. The corrected-source run is **1554 tests in 71 files**: exactly one obsolete unsupported test was deleted — `McpCommand.spec.ts` "scope action using positional argument options._", whose only caller was the removed `options._?.[0]` fallback. No supported assertion was removed or weakened. Counts here are runner totals and are not independent scenario counts.

## 3. Retained failure and non-defects

- **Routing smoke resolved; original failure retained as fixture history.** The original case passed `broad_globs: []` and asserted the P0 bold observable (`**ts-base**` absent), so the failure combined an empty broad-glob map with that bold expectation; the specific-skill row was never isolated, which made the expected observable confounded. The corrected fixture holds `broad_globs` constant across the pair and varies only `base_language_skills`: empty map leaves the broad-covered skill in Keyword Match, configured map promotes the same skill to File Match. Both halves pass, along with the 12 previously passing fixtures, in `smoke-routing-final.json` (14/14, exit 0). No production source changed for this correction; the original FAIL stays recorded and is not reclassified as a product defect.
- **Subprocess shell-free label is a source-level claim.** `PASS … gh invoked without shell expansion` in `smoke-subprocess.log` is derived from the adapter's argument construction as inspected, not from an independent execution trace proving no shell was interposed. Retained verbatim as an overclaim; the actual executed evidence is the four scenario outcomes plus manifest cleanup.
- **Scope-smoke setup failure, distinct from the predecessor's.** The first `scope-smoke` run (`smoke-scope.json`/`.log`, 2026-11-06T07:03:15.502Z → 07:03:15.556Z, exit 1) never reached the CLI: `SyntaxError: The requested module 'js-yaml' does not provide an export named 'default'` at `scope-smoke.mjs:35`, because the installed js-yaml 5 ships no default export. The harness was fixed to the named loader `import { load as loadYaml } from 'js-yaml'`; `smoke-scope-final.json` then passed all five invocations. This is a throwaway-harness setup failure in this repair, not the earlier stage/generation-ownership failure of the predecessor initiative.
- **Earlier stage/harness setup failure is not a product defect.** The predecessor `--check` exit 1 / generation-ownership failure was a staging-and-ownership precondition, resolved by an authorized base adoption; it does not describe a runtime fault in these changes and must not be conflated with the scope-smoke loader failure above.
- **Original 17-diagnostic RED is unchanged.** `.agent/sdd/critical-thinking-agent-workflows/repair-typecheck-cli.log` (SHA-256 `05da4ee7…`) remains the historical failing receipt; `compiler-cli.json` records the separate 1-diagnostic intermediate state. Neither is rewritten or superseded in place.

## 4. Inherited limits and warnings

- **4 MCP skips**, never counted as passes: 3 Windows-only tests and 1 unconditional performance skip (`full-mcp.json` 979 pass + 4 skip = 983).
- **Current-host only.** Every result above was observed on this host (darwin/arm64). No Node 20, Windows, or minimum-runtime claim is made; the compiler conformance claim is bounded to the configured `ES2022` library, which is unchanged.
- **Warnings retained, not clean-warning runs:** Vite native-config-loader warning; CLI fixtures emitting git-not-repository and security-stripping messages while exiting zero.
- **Root-generation evidence is bounded.** `root-generation` recorded `Copied back: none (up to date)`, which proves no generated resource was copied back into the tree; `root-generation-check` separately passed. Neither run proves that no file anywhere was written or establishes lockfile byte identity. No dependency/lockfile regeneration was assigned to workers. Task 3 disclosed one prohibited `perl` edit to its own temporary routing harness; that command deviation remains recorded and is not a production edit or compliant execution claim.
- **Consumer scope:** the root consumer smoke exercised a freshly launched same-root source MCP child; persistent MCP processes may still need restart or update.

## 5. Audit checkpoint and open items

- `final-trace.json` PASS (2026-11-06T07:17:05.729Z → 07:17:06.343Z) and `final-outcome.json` PASS (2026-11-06T07:17:06.406Z → 07:17:07.024Z) are chronological checkpoints recorded before this documentation freeze. Because these edits changed the documents afterwards, neither result attests to the current document bytes, and this report does not cite its own audit outcome as evidence for itself. The affected auditors are refreshed only after the next freeze.
- Remaining: final documentation/evidence review of this record, the plan delivery section and the SRS follow-up note, then the scoped document audit refresh.
- Maintainer decisions outside this record: human acceptance, merge, release, and any client rollout — none authorized or claimed here.

No compiler, runtime, preservation or smoke lane remains open. Business acceptance, formal host provenance and release remain separate and unassessed; live efficacy, persistent-client behavior, minimum Node and Windows were not exercised; cost is unavailable, so no monetary or savings figure is stated.

**FINAL_FROZEN** — documentation-only receipt; no production, test, harness or generated file was modified by the owner of this report.
