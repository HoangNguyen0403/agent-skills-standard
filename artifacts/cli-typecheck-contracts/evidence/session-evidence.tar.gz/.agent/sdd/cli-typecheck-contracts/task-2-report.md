# Task 2 report — private config serializer contract

- Task: cli-typecheck-2 (plan `8404f825ae8658…`, source revision `1c79a7edb22b…`)
- Owner: task-2 sole bounded implementation worker
- Status: **FINAL_FROZEN**
- Writes: `cli/src/services/ConfigService.ts`, this report. No other path touched.

## 1. Edits (one file, three hunks)

Retained RED evidence (`.agent/sdd/critical-thinking-agent-workflows/repair-typecheck-cli.log`) contains exactly one
ConfigService diagnostic:

```
src/services/ConfigService.ts(589,23): error TS2352: Conversion of type 'SkillConfig' to type
'Record<string, unknown>' may be a mistake … Index signature for type 'string' is missing in type 'SkillConfig'.
```

| # | Line (post-edit) | Before | After |
| --- | --- | --- | --- |
| 1 | 124 | `private dumpConfig(config: Record<string, unknown>): string {` | `private dumpConfig(config: SkillConfig \| Record<string, unknown>): string {` |
| 2 | 447 (`loadConfig` migration write) | `this.dumpConfig(source.config as unknown as Record<string, unknown>),` | `this.dumpConfig(source.config),` |
| 3 | 587 (`saveConfig`) | `this.dumpConfig(config as Record<string, unknown>),` | `await fs.outputFile(primaryConfigPath, this.dumpConfig(config));` |

Hunk 3 also collapses the former four-line `fs.outputFile(` call to a single line: with the cast removed the
call is 68 columns, inside the repo's default Prettier width (no `.prettierrc`, no `prettier` key in either
`package.json`; comparable short call already single-line at line 521). No statement, argument order, or
callee changed.

Third call site (line 520, `saveSelection` → `this.dumpConfig(merged)`) already passed
`Record<string, unknown>` and is untouched.

No exported symbol changed; `dumpConfig` is `private` and file-local, so no external consumer or reference
sweep applies.

## 2. Why behavior is unchanged

- **No allocation:** the parameter type is erased at emit, and the edited call sites pass their argument
  straight through — `source.config` and `config` are handed to `dumpConfig` unchanged, with no clone, spread,
  or normalization introduced. This is an inspected-source property, not a runtime observation.
  `ConfigService.spec.ts:343` asserts `expect(yaml.dump).toHaveBeenCalledWith(mockConfig, { noRefs: true, lineWidth: -1 })`;
  that matcher performs a deep equality comparison of the serialized input and the options object, so it does
  **not** prove reference identity and would also pass for a deep-equal clone. It remains the unmodified oracle
  for serialized input plus dump options, not for object identity.
- **YAML options:** `yaml.dump(config, { noRefs: true, lineWidth: -1 })` body untouched.
- **Migration ordering:** `loadConfig` still writes `.skillsrc` before `fs.remove(source.sourcePath)`; the
  conditional (`migratedFromText || migrated || shouldRenameLegacyYamlFile`) is untouched.
- **Legacy delete ordering:** `saveConfig` still writes the primary file before removing `.skillsrc.yaml`.
- **Raw merge:** `saveSelection` still copies `snapshot.raw`, rewrites only `skills`/`skills_mode`, retains
  unknown root and per-category extension fields. `merged` stays `Record<string, unknown>`.
- **Validation:** `SkillConfigSchema` and both `safeParse` call sites untouched — no broadening.

Static reasoning on the diagnostic: `SkillConfig` is a closed interface without an index signature, so it is
not assignable to `Record<string, unknown>`; it *is* a member of the new union, so `this.dumpConfig(config)`
and `this.dumpConfig(source.config)` need no conversion and TS2352 cannot be reported at that site.
Not executed — see §4.

## 3. Negative invariants

- No `any`, no `as unknown as`, no remaining `as Record<string, unknown>` (verified by search on the file).
- No index signature added to `SkillConfig`, no new type alias, no `Pick`/`Partial` helper.
- No allocation, no dropped raw fields, no file-operation change, no new file ownership.
- No compiler option, lib, target, dependency, or test change. `ConfigService.spec.ts` not edited.

## 4. NOT RUN (packet-forbidden; parent owns all execution)

- `rtk pnpm --dir cli exec tsc --noEmit` — not run; no claim that the compiler passes, only that the sole
  retained ConfigService diagnostic's cause is removed by construction.
- `rtk proxy pnpm --dir cli exec vitest run src/services/__tests__/ConfigService.spec.ts` — not run.
- CLI suite, lint, `format:check`, generators, LSP/type diagnostics — not run (packet also forbids syntax checks).
- Post-edit SHA-256 of `ConfigService.ts` not computed (requires a command); the packet's frozen digest
  `f9ec9582…` describes the pre-edit input.

## 5. Parent verification handoff

1. `rtk proxy pnpm --dir cli exec vitest run src/services/__tests__/ConfigService.spec.ts`
   — expect existing migration / `saveConfig` serialized-input-and-options / extension-preservation / conflict /
   legacy-delete cases pass with assertions unchanged.
2. `rtk pnpm --dir cli exec tsc --noEmit` — expect exit 0 after Task 1 and Task 3 also freeze; ConfigService
   diagnostic absent, options unchanged.

**FINAL_FROZEN** — all owned writes stopped. No further edits until an explicit parent correction.
