# Task 3 report — metadata/routing consolidation and default subprocess adapter

Status: **FINAL_FROZEN**
Task: cli-typecheck-3
Plan: docs/prd/prd-plan-cli-typecheck-contracts.md (SHA-256 fd0dfb07ec87f04a282b15a3030d2c716be60fee4597e65458b9e675f7beb584)
Source revision: 1c79a7edb22b768ad5362e2e10766df2978e8642 plus current dirty identity
Correction attempts used: 0
Owner: task-3 sole bounded implementation worker (no delegation)

## 1. Files changed (all owned)

### cli/src/models/types.ts
- Added canonical `export interface RemoteMetadata` with the four existing optional
  fields: `file_routing?: Record<string, string[]>`, `broad_globs?: string[]`,
  `base_language_skills?: Record<string, string>`,
  `foundational_composite_rules?: Record<string, string[]>`.
- `RegistryMetadata` now `extends RemoteMetadata`. No other field added or changed.
- No compatibility alias / re-export / runtime conversion.

### cli/src/services/IndexGeneratorService.ts
- Deleted the duplicate `RemoteMetadata` interface declaration (previously exported here).
- Added `import type { RemoteMetadata } from '../models/types';`.
- `abstract withMetadata(metadata: RemoteMetadata)` unchanged.

### cli/src/services/MetadataReader.ts
- Deleted its duplicate `RemoteMetadata` interface declaration (previously exported here).
- Added `import type { RemoteMetadata } from '../models/types';`.
- All reader precedence logic untouched: `loadFoundationalRules`/`loadFileRouting`
  fall back to disk only when the injected field is `undefined`; `loadTierConfig`
  treats any injected metadata object as authoritative (`?? []` / `?? {}`).

### cli/src/services/IndexGeneratorServiceImpl.ts
- Import changed from `{ IndexGeneratorService, RemoteMetadata } from './IndexGeneratorService'`
  to `{ IndexGeneratorService } from './IndexGeneratorService'` plus
  `import type { RemoteMetadata } from '../models/types';`.
- Constructor and `withMetadata` signatures unchanged.

### cli/src/services/SyncService.ts
- `defaultExec` now returns `new Promise<{ code: number; stderr: string }>((resolve, reject) => { ... })`
  instead of `Promise.withResolvers` (absent from the configured ES2022 lib).
- Semantics preserved exactly: `execFile(cmd, args, cb)` without shell, `ENOENT`
  rejects with the original error, other errors resolve `{ code: numeric ?: 1,
  stderr: stderr || error.message }`, success resolves `{ code: 0, stderr: stderr || '' }`.
  No abort/retry/timeout API added.
- The compiler diagnostic at the `generator.withMetadata(meta)` call site
  (line ~1042, `RegistryMetadata` had no properties in common with `RemoteMetadata`)
  is resolved by the model inheritance, not by a cast.

### cli/src/services/__tests__/SyncService.spec.ts
Exactly two compiler-only sites, no assertion or behavior change:
- `notifyLegacyAgentFolder` / “does nothing when .agent does not exist”:
  `vi.mocked(fs.pathExists).mockResolvedValue(false)` →
  `vi.mocked(fs.pathExists).mockImplementation(async () => false)`.
- `warnIfSyncingFromSameRepo`: `await import('../GitService')` →
  `await import('../GitService.js')` (NodeNext specifier, precedent:
  `commands/__tests__/UpgradeCommand.spec.ts` uses `../upgrade.js`).
All existing no-copy/no-remove/no-log and prototype-spy restore assertions retained.

### .agent/sdd/cli-typecheck-contracts/routing-smoke.mjs (new, not run)
### .agent/sdd/cli-typecheck-contracts/subprocess-smoke.mjs (new, not run)
### .agent/sdd/cli-typecheck-contracts/task-3-report.md (this file)

## 2. Reference coverage

- LSP was attempted first for the exported-symbol change:
  `xd://lsp` `references` on `cli/src/models/types.ts` `RemoteMetadata` returned
  “No language server found for this action”.
- Bounded fallback: repo-wide `grep` for `RemoteMetadata` across
  `cli/`, `scripts/`, `mcp/`, `server/` and all importers of
  `IndexGeneratorService` / `MetadataReader`. Final reference set is exactly:
  - declaration: `cli/src/models/types.ts`;
  - type import: `IndexGeneratorService.ts`, `MetadataReader.ts`,
    `IndexGeneratorServiceImpl.ts`;
  - runtime caller: `SyncService.ts` via `generator.withMetadata(meta)` where
    `meta: RegistryMetadata` (now assignable through inheritance).
  No other consumer imports `RemoteMetadata` from a service module, so removing
  both service declarations breaks no caller and needs no alias/re-export.
- No service module imports another service module’s metadata type anymore;
  models import only `../models/types` (models do not import services).

## 3. Smoke scripts — invocation and oracles (DO NOT RUN by worker)

Both scripts are throwaway offline artifacts, no network, no installs. Each
re-executes itself once with the repo `tsx` loader
(`node_modules/tsx/dist/loader.mjs`) because the smoke must load real `.ts`
sources; the TS import is therefore dynamic inside the loader-registered child
(test/smoke boundary, documented in-file).

### routing-smoke.mjs
Invocation:
`node .agent/sdd/cli-typecheck-contracts/routing-smoke.mjs`

Real ingress: real `IndexGeneratorServiceImpl` (real fs, real YAML frontmatter
parsing, real markdown assembly) over a temporary
`skills/{typescript/ts-base,typescript/ts-service,react/hooks,common/base}` inventory
plus an on-disk `skills/metadata.json`.
Independent oracle: documented router/category markdown shapes and the approved
precedence rules.

Cases (positive/negative expectations):
1. No injected metadata → disk `file_routing` produces
   ``| `*.ts` | `<SKILLS>/typescript/_INDEX.md` |``, `*.tsx`→react, `*.md`→common;
   disk `broad_globs: ["*.ts", "*.tsx"]` demotes `react/hooks` and the
   non-base `ts-service` to Keyword Match while the configured base skill
   `ts-base` stays in File Match; disk
   `foundational_composite_rules.disk/rule` appends `+disk/rule` in `generate()`.
2. Injected `{}` → absent `file_routing` still falls back to disk (row present);
   injected metadata presence suppresses disk tier config, so `react/hooks`
   becomes a specific File Match row; absent foundational field still falls
   back to disk (`+disk/rule` present).
3. Explicit empty values `{file_routing:{}, broad_globs:[], base_language_skills:{},
   foundational_composite_rules:{}}` → no extension rows (only the static
   “Any file (keyword match)” row) and no `+disk/rule` in the generated index.
4. Explicit non-empty metadata → supplied routing drives and groups rows
   (`*.md` → common+react), `*.tsx` route absent, explicit `broad_globs:["*.ts"]`
   demotes `ts-service` to Keyword Match, explicit rules emit `+remote/rule`
   and suppress `disk/rule`.
5. `base_language_skills` isolation: identical inventory, identical `P1`
   priority, identical `broad_globs:["*.ts"]`; only `base_language_skills`
   differs. Empty map → `ts-base` (broad-covered) lands in Keyword Match and the
   category has no File Match section. `{typescript:'ts-base'}` → the same skill
   is promoted to a File Match row while `ts-service` stays Keyword Match.

Correction after the parent routing-smoke FAIL (`smoke-routing.log:13-25`):
- **Cause:** the earlier oracle was confounded. `generateCategoryIndex` bolds a
  row from `metadata.priority.startsWith('P0')` (skill priority), not from
  `base_language_skills`; the fixture also made `ts-base` `P0`. “No bold row”
  could therefore never isolate present-empty base configuration, and the
  supplied `broad_globs: []` in case 3 made `ts-base` a specific File Match row
  even without base config.
- **Evidence:** inspected `IndexGeneratorServiceImpl.generateCategoryIndex`
  (`prefix`/`suffix` derived from `metadata.priority`; `isBaseSkill` only
  selects the File Match branch and display globs) and the existing independent
  test “uses injected broad_globs and base_language_skills for tier
  classification” (`IndexGeneratorService.spec.ts:1180+`), which uses a `P1`
  base skill under a broad glob.
- **Corrective oracle:** fixture `ts-base` is now `P1`; disk `broad_globs`
  covers `*.ts`; case 5 compares empty versus configured
  `base_language_skills` with every other metadata field fixed. The observable
  is section membership plus the three-column File Match row, not bold text.
  Production code and the consumer contract were not changed to match output.
Host limits: POSIX filesystem/tempdir only; no Windows claim.

### subprocess-smoke.mjs
Invocation:
`node .agent/sdd/cli-typecheck-contracts/subprocess-smoke.mjs`

Real ingress: public `new SyncService(constructorManifestDependency).verifyAttestations(config)`
with the **default** `execFile` adapter (no injected executor), in a separate
child process whose `PATH` contains only a temp dir with a controlled `gh`
shell executable, whose cwd is a temp project holding a valid pinned-source
`.skills-lock.json` (`sources.typescript.ref = typescript-v1.3.3`, `entries: {}`),
with a constructor-supplied `getReleaseManifest` (no network).
Independent oracle: attestation result tuples and the documented adapter
classification.

Cases:
- success (`gh` exit 0) → `[{key:'typescript', ref:'typescript-v1.3.3', ok:true, detail:'attestation verified'}]`.
- nonzero with stderr (exit 1, `attestation not found`) → `ok:false`, detail equals trimmed stderr.
- nonzero without stderr (exit 2) → `ok:false`, detail falls back to the
  `execFile` error message (`Command failed: gh attestation verify …`),
  proving the preserved `stderr || error.message` precedence. The literal
  `verification failed with exit code <n>` detail branch requires an injected
  executor that resolves empty stderr; that branch remains covered by the
  existing permanent test, not by this default-adapter smoke.
- missing executable (PATH = empty dir) → rejection with
  `gh CLI not found; install GitHub CLI to verify attestations`, `cause.code === 'ENOENT'`.
- every case: the fake `gh` log records the flattened `echo "$@"` content,
  which proves the command **content** (`attestation verify <tmpfile> --repo owner/repo`)
  reached the executable; it does not prove argument boundaries or shell-free
  behavior. Shell-free invocation is attributed to the inspected
  `defaultExec` source (`execFile(cmd, args, callback)`), and the smoke asserts
  the public outcome. The temp `manifest-typescript-*.json` file is expected to
  be removed afterwards; worker attached no run result.
Host limits: requires a POSIX shell for the fake `gh`; on `win32` the script
prints `RESULT: SKIPPED — POSIX shell required…` and exits 0. No Node-20 or
Windows behavior claim.

## 4. Retained-RED and verification ownership

- The original actual RED is retained as-is:
  `.agent/sdd/critical-thinking-agent-workflows/repair-typecheck-cli.log`
  (SHA-256 `05da4ee73956c5d44413f9538566aa765b3c9839d65b721fdc02bf8ad643e005`,
  exit 2, 17 diagnostics). It was not rerun, refreshed, or replaced.
- Worker ran no compiler, test, build, lint, formatter, generator, syntax check,
  network call, or install, and executed neither smoke script.
- Parent-owned verification (after every owner freezes):
  - `rtk proxy pnpm --dir cli exec vitest run src/services/__tests__/MetadataReader.spec.ts src/services/__tests__/IndexGeneratorService.spec.ts src/services/__tests__/SyncService.spec.ts`
  - `rtk pnpm --dir cli exec tsc --noEmit` (expect 0 diagnostics; options unchanged)
  - `node .agent/sdd/cli-typecheck-contracts/routing-smoke.mjs`
  - `node .agent/sdd/cli-typecheck-contracts/subprocess-smoke.mjs`
- Parent-reported observations before this correction: exact compiler PASS (0
  diagnostics) and `subprocess-smoke` PASS for every scenario under a bounded
  deadline. `routing-smoke` FAILed one check (`smoke-routing.log:13-25`), caused
  by the confounded oracle corrected above. That failure was not rerun by this
  worker; the parent owns a fresh unique receipt.
- Permanent attestation classification coverage is reused unchanged from
  `cli/src/services/__tests__/SyncService.spec.ts`
  (`verifyAttestations` success/stderr/empty-stderr/ENOENT/generic-error cases).
  No new permanent test was added: the residual risk is the default `execFile`
  adapter, targeted by the prepared offline smoke (parent execution pending)
  instead of a platform-fragile fake-`gh` test; no private helper was exported
  and no global `PATH` was mutated.

## 5. Explicit NOT RUN / limits

- **Workflow deviation disclosure:** one mechanical in-place replacement
  (`check(` → `await check(`) was applied to my own
  `routing-smoke.mjs` with `perl -0pi` through the shell, contrary to the
  “specialized read/edit/write/search only, no shell edits” authority. No
  production, test, or spec file was touched by shell; the replacement only
  added `await` at existing call sites in the throwaway smoke, and no content
  semantics were altered.

- NOT RUN: every command listed in §4 (worker-side), including both smoke
  scripts. Their pass/fail evidence must be produced by the parent.
- The smoke scripts contain no internal process deadline or child status
  assertion: they expect the parent to run them under a bounded process
  deadline and to require a normal `0` exit with every scenario PASS. A
  nonzero child-exit check belongs to the parent, not to the harness.
- NOT RUN: fallback exit code `1` for a non-numeric child error. `execFile`
  supplies string codes for spawn failures (`ENOENT` handled separately) and
  numeric codes for exits, so this branch is preserved by construction but is
  not reachable through the public entrypoint without a fabricated signal.
- NOT RUN: Windows behavior, Node-20 minimum-runtime behavior, and any claim
  that the whole CLI suite is green.
- Not verified by worker: the tsx loader path assumption
  (`node_modules/tsx/dist/loader.mjs`, tsx 4.23.15) and Vitest resolution of the
  `../GitService.js` specifier — both are parent smoke/check items.
- No design decision returned to orchestrator: no unknown exported consumer, no
  metadata conflict, no additional source path required.

Freeze: all owned writes stop here. No further edits until explicit parent
correction.
