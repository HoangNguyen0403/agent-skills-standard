# Task 1 report — cli-typecheck-1

Status: **FINAL_FROZEN** — revision 4; report-only corrections (rev 2), one acceptance-failure source correction (rev 3, `UninstallCommand.spec.ts`), and one harness-only corrective (rev 4, `scope-smoke.mjs`). No commands, tests, or production/spec edits in rev 4 by this owner.
Owner: task-1 sole bounded implementation worker
Plan: `docs/prd/prd-plan-cli-typecheck-contracts.md` (approved; plan SHA-256 `fd0dfb07ec87f04a282b15a3030d2c716be60fee4597e65458b9e675f7beb584`)
Readiness: `readiness.json` verdict READY. Authority: `authority.json` (Subagent-Driven, worker runs no commands).
Retained RED: `.agent/sdd/critical-thinking-agent-workflows/repair-typecheck-cli.log` (exit 2, 17 diagnostics on source revision `1c79a7ed…` + current dirty identity). Not rerun by this worker.

Parent-observed compiler result after all owners froze (`.agent/sdd/cli-typecheck-contracts/compiler-cli.log`, exit 2): exactly one remaining diagnostic —
`src/commands/__tests__/UninstallCommand.spec.ts(56,7): error TS2345: Argument of type 'Mock<Constructable | Procedure>' is not assignable to parameter of type '((m: string) => Promise<boolean>) | undefined'`.
Parent then observed the actual final compiler PASS (0 diagnostics) at `.agent/sdd/cli-typecheck-contracts/compiler-cli-final.json`. Both are parent runs, not worker runs; this owner makes no fresh-green claim. Subprocess and routing smokes remain NOT RUN (parent `&&` chain stopped at the scope smoke setup error).

Revision 2 corrections (report text only): (a) supported-CLI smoke is prepared, proof pending parent — not claimed as evidence; (b) invalid-scope step states the exact checked fields and cites the existing unit no-save assertion instead of claiming smoke-observed immutability; (c) fallback-cutover evidence is source/reference review, because the prepared smoke cannot distinguish the removed `_` read.

Revision 3 correction (source, owned path): `confirmMock` carried the broad `ReturnType<typeof vi.fn>` type, so the mock's own `Mock<Constructable | Procedure>` shape did not satisfy the constructor seam. Now `let confirmMock: Mock<(message: string) => Promise<boolean>>` (same signature as `uninstall.ts:28` `confirm?: (m: string) => Promise<boolean>`; name matches the class field `private confirm: (message: string) => Promise<boolean>` at `uninstall.ts:22`) and `confirmMock = vi.fn<(message: string) => Promise<boolean>>().mockResolvedValue(true)`. No cast, widening, or assertion change; every `confirmMock` assertion (`not.toHaveBeenCalled`, `toHaveBeenCalled`), the `mockResolvedValue(false)` decline case, TTY mock, log spy, and lifecycle hooks are untouched.

Revision 4 correction (harness only, `.agent/sdd/cli-typecheck-contracts/scope-smoke.mjs`): the smoke failed at setup, before any CLI child process, with `.agent/sdd/cli-typecheck-contracts/smoke-scope.log` `SyntaxError` — `import yaml from 'js-yaml'` at old line 35, because the installed `js-yaml` 5.5.0 (`exports["."].import` → `dist/js-yaml.mjs`) has no default export. Classified as an **invalid smoke** (setup/import error), not a production-behavior failure: no CLI invocation, no assertion, and no oracle result was produced, so nothing about `mcp scope` behavior is implied. Fix: `import { load as loadYaml } from 'js-yaml'` and `const parsed = loadYaml(raw)` — the supported ESM named export the package actually declares (verified `load`/`dump` in the export statement of `dist/js-yaml.mjs`; matches the repo's own `import * as yaml` + `yaml.load` usage in `ConfigService.ts:3,395`). No dependency/version/runtime change; every oracle (steps 1-6 incl. both config parses), the child-local env isolation, and the assertions are unchanged — only the import form changed.

## Changed files (exact)

1. `cli/src/commands/mcp.ts:190` — `actionScope` now reads `const scope = options.scope;` (removed `?? options._?.[0]`), with a comment stating the Commander adapter maps positional scope onto `options.scope` and preserves explicit `--scope` precedence (`cli/src/index.ts:239-245`). Scope validation, default fallback (`defaultMcpConfig()`), `prompted: true`, save, user-scope notice unchanged; only the unsupported `_` first-element read is gone.
   Fixes: `McpCommand.spec.ts(433,36) TS2322` diagnostic source (removed caller).
2. `cli/src/commands/__tests__/McpCommand.spec.ts:427` — removed the duplicate `scope action using positional argument options._` test. Supported behavior stays covered by the pre-existing `handles "scope" action correctly` (`run('scope', { scope: 'user' })`, save-config assertion, `MCP scope set to "user"` output), `rejects invalid "scope" value`, the install `--scope` handling/validation tests, and the `user`-scope mismatch tests. No unit test asserts positional-versus-flag precedence; that is delegated to the prepared Commander smoke (oracle 2). No assertion weakened or re-pinned.
3. `cli/src/commands/__tests__/UninstallCommand.spec.ts:8,29-31,47-51` — added `type Mock` to the vitest import; `let isTTYMock: Mock<() => boolean>` with `vi.fn<() => boolean>().mockReturnValue(true)`; revision 3 also types `let confirmMock: Mock<(message: string) => Promise<boolean>>` with `vi.fn<(message: string) => Promise<boolean>>().mockResolvedValue(true)`. Constructor seams `isTTY?: () => boolean` (`uninstall.ts:27`) and `confirm?: (m: string) => Promise<boolean>` (`uninstall.ts:28`) unchanged; all confirmation/TTY assertions, the decline case, and lifecycle hooks untouched.
   Fixes: `UninstallCommand.spec.ts(54,7) TS2345` (TTY mock) and the parent-observed residual `UninstallCommand.spec.ts(56,7) TS2345` (confirm mock).
4. `cli/src/commands/__tests__/UpgradeCommand.spec.ts:34-36` — dynamic import is now `await import('../upgrade.js')`, still immediately after `vi.resetModules()` (static import cannot work: the module must re-bind after reset so the `fs`/`child_process` mocks apply; comment records that reason). Mock ordering and assertions unchanged.
   Fixes: `UpgradeCommand.spec.ts(34,30) TS2835`.
5. `cli/src/commands/__tests__/VerifyCommand.spec.ts:1-9,28` — added `type MockInstance` to the vitest import and typed `let logSpy: MockInstance<typeof console.log>` (was `ReturnType<typeof vi.spyOn>`, which erased callback parameter inference). `logSpy.mockRestore()` and all output/exit-code assertions unchanged.
   Fixes: five `TS7006` diagnostics at 177/202/243/268/292.
6. `cli/src/services/__tests__/HookService.spec.ts:7-11,684` — `KIRO_HOOK_MD` added to the existing static `../HookService` import; the redundant `await import('../HookService')` inside the Kiro update test removed. Installed-byte equality assertion (`readFile(hookPath,'utf8') === KIRO_HOOK_MD`) preserved.
   Fixes: `HookService.spec.ts(680,45) TS2835`.
7. `cli/src/services/validation/__tests__/interopRules.spec.ts:83-86,106-109,127-129` — dropped the obsolete second `filePath` argument on the three content-only calls (`AgentSkillsSpecRule` helper, `TriggerPhraseRule` helper, block-scalar `TriggerPhraseRule` case). Production signatures untouched; `NameMatchesDirectoryRule`, `ReferenceLinksRule`, and `BodySizeRule` path-dependent calls, name/trigger/block-scalar/dead-link assertions all retained.
   Fixes: three `TS2554` diagnostics at 86/110/131.
8. `.agent/sdd/cli-typecheck-contracts/scope-smoke.mjs` — new isolated offline smoke; never executed by this owner. Revision 4 changed only the YAML reader to js-yaml 5's ESM named export (`import { load as loadYaml } from 'js-yaml'`, `loadYaml(raw)`) after the setup `SyntaxError`; oracles, env isolation, and assertions unchanged.
9. `.agent/sdd/cli-typecheck-contracts/task-1-report.md` — this report.

Not touched: `cli/src/services/__tests__/SyncService.spec.ts` (Task 3), `ConfigService.ts` (Task 2), `SyncService.ts`, models/services metadata (Task 3). No `any`, cast, suppression, assertion weakening, API widening, or assertion re-pinning introduced.

## Acceptance criteria mapping

- **Compiler** — all 12 originally logged owned diagnostic sites (1 × TS2322, 1 × TS2345, 1 × TS2835-commands, 5 × TS7006, 1 × TS2835-services, 3 × TS2554) addressed at their source, plus the single parent-observed residual at `UninstallCommand.spec.ts(56,7)` fixed in revision 3, with no compiler option/lib/target change. Parent then observed the actual final PASS, 0 diagnostics, at `.agent/sdd/cli-typecheck-contracts/compiler-cli-final.json`; this owner ran no compiler and claims no green of its own.
- **Supported CLI** — positional MCP scope plus explicit `--scope` precedence preserved in `actionScope`; a prepared isolated Commander smoke (steps 1-5 below) is the intended proof and remains parent-run/pending, not evidence from this owner. Obsolete unsupported `_` array path and its duplicate test removed together; no registration/install/sync performed.
- **No bypass** — no `any`, double-cast, `@ts-*`, eslint/ts suppression, or weakened assertions; mocks keep their behavioral assertions and only gain precise types; the only deletions are the unsupported `_` fallback and its duplicate test.
- **Preservation** — TTY prompt behavior, output assertions, installed-byte equality, validator assertions, and module-reset isolation are unchanged in behavior; existing supported `scope: user` test retained.

## Smoke script — invocation and oracles (parent to run)

```
node .agent/sdd/cli-typecheck-contracts/scope-smoke.mjs
```

Ingress: real source CLI `cli/src/index.ts` under `node --import <repo tsx>`, cwd = throwaway project dir containing a schema-valid `.skillsrc` (`registry` URL, `agents: [claude]`, `skills: {}`), with child-local `HOME`/`USERPROFILE`/`XDG_*`/`APPDATA`/`LOCALAPPDATA` and `NO_COLOR=1`. Offline: only `mcp scope` runs.

Oracles (each asserted on the actual saved YAML, parsed with `js-yaml`):
1. `mcp scope user` → exit 0, `MCP scope set to "user"`, saved `mcp.scope=user`, `mcp.prompted=true`, default `mcp.enabled=false` preserved.
2. `mcp scope project --scope user` → saved `mcp.scope=user` and explicitly not `project` (flag precedence).
3. `mcp scope snippets-only` → saved `mcp.scope=snippets-only` (positional honoured without a flag).
4. `mcp scope --scope user` → saved `mcp.scope=user` (flag-only form).
5. `mcp scope bogus` → exit 0, `Invalid scope` reported, and the checked fields unchanged (`mcp.scope=user`, `mcp.prompted=true`, `mcp.version` still absent). The smoke does not observe the save itself; the no-save contract is covered separately by the existing unit test `rejects invalid "scope" value`, which asserts `saveConfig` was not called.
6. Child-local HOME contains no created files; no `mcp-config-snippets/` in the project.

Negative expectations: the smoke verifies only supported positional and `--scope` behavior (steps 1-5); it does **not** detect the removed fallback. Re-adding `options._?.[0]` would still pass, because the Commander adapter (`cli/src/index.ts:239-245`) always populates `merged.scope` for both forms, so `_` is never consulted. The `_` cutover is established by source inspection of `actionScope` plus a repository-wide check that no `options._`/`_: [` caller remains — not by the smoke.

## NOT RUN (parent owns all execution)

- `rtk pnpm --dir cli exec vitest run <six owned spec files>` — NOT RUN by worker; parent observed the focused suite PASS (10 specs) before revision 3.
- `rtk pnpm --dir cli exec tsc --noEmit` — NOT RUN by worker. Retained 17-diagnostic RED, then the parent-observed one-diagnostic failure, then the parent-observed 0-diagnostic PASS at `compiler-cli-final.json`; no worker compiler run.
- `node .agent/sdd/cli-typecheck-contracts/scope-smoke.mjs` — NOT RUN by worker. Parent's first attempt stopped at setup (`smoke-scope.log`, invalid smoke, revision 4 harness fix); the rerun under a unique log is pending, so smoke proves nothing yet.
- Subprocess and routing smokes (Task 3) — NOT RUN; the parent `&&` chain stopped at the scope-smoke setup error.
- Full CLI suite, MCP/generator gates, lint/format/generation — NOT RUN.

## Risks / limits

- NodeNext `.js` specifier for `../upgrade.js` must still resolve under Vitest + `vi.resetModules()`; compiler and runtime gates are both required (existing suite convention already imports `../upgrade` only dynamically, so the runtime resolution is unverified here).
- `MockInstance<typeof console.log>` takes `console.log`'s own `any[]` parameter tuple, so `c` in `logSpy.mock.calls.map((c) => …)` is typed rather than implicitly `any`; no assertion semantics changed.
- `import.meta.resolve('tsx')` requires Node >= 20.6 (repo engines declare >= 20.0.0). Current host only; no Windows/minimum-runtime claim.
- The removed `_` fallback is supported by source inspection plus the absence of any remaining `options._`/`_: [` caller in `cli/src`, not by the smoke (the Commander adapter always supplies `merged.scope`, so an unexecuted `_` read is undetectable at runtime). Repository-scope only; no claim about external/implicit callers.
- Historical raw evidence retained; no feigned green.
